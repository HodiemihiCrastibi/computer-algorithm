#include <iostream>
#include <vector>
#include <queue>
#include <climits>
#include <chrono>

using namespace std;
using namespace std::chrono;

// 그래프 클래스 정의
class Graph {
public:
    int vertices; // 정점의 개수
    vector<vector<pair<int, int>>> adjList; // 인접 리스트

    // 생성자
    Graph(int V) : vertices(V), adjList(V + 1) {}

    // 간선 추가 함수
    void addEdge(int u, int v, int weight) {
        adjList[u].emplace_back(v, weight);
        adjList[v].emplace_back(u, weight);
    }

    // Prim's 알고리즘을 사용하여 최소 신장 트리 구하기
    vector<pair<int, int>> primMST() {
        vector<pair<int, int>> mst; // 최소 신장 트리 간선 저장
        vector<int> key(vertices + 1, numeric_limits<int>::max());
        vector<bool> inMST(vertices + 1, false);

        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;

        // 임의의 시작 정점을 선택
        int startVertex = 1;
        key[startVertex] = 0;
        pq.push({ 0, startVertex });

        while (!pq.empty()) {
            int u = pq.top().second;
            pq.pop();

            if (inMST[u]) {
                continue;
            }

            inMST[u] = true;

            for (auto& edge : adjList[u]) {
                int v = edge.first;
                int weight = edge.second;

                if (!inMST[v] && weight < key[v]) {
                    key[v] = weight;
                    pq.push({ key[v], v });
                }
            }
        }

        // 최소 신장 트리 간선 저장
        for (int v = 2; v <= vertices; ++v) {
            mst.emplace_back(v, key[v]);
        }

        return mst;
    }
};

int main() {
    // 그래프 생성 및 간선 추가
    Graph graph(6);
    graph.addEdge(1, 2, 4);
    graph.addEdge(2, 3, 7);
    graph.addEdge(1, 4, 5);
    graph.addEdge(1, 5, 2);
    graph.addEdge(2, 5, 9);
    graph.addEdge(3, 6, 8);
    graph.addEdge(4, 5, 6);
    graph.addEdge(5, 6, 3);

    // 최소 신장 트리 간선 출력
    vector<pair<int, int>> mst = graph.primMST();
   
    cout << "최소 신장 트리 간선:" << endl;
    for (auto& edge : mst) {
        cout << "(" << edge.first << " " << edge.second << ") ";
    }
    return 0;
}
