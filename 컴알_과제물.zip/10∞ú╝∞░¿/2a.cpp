#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <queue>

using namespace std;

// 그래프 클래스 정의
class Graph {
public:
    int vertices; // 정점의 개수
    vector<vector<int>> adjMatrix; // 인접 행렬

    // 생성자
    Graph(int V) : vertices(V), adjMatrix(V, vector<int>(V, 0)) {}

    // 간선 추가 함수
    void addEdge(int u, int v) {
        adjMatrix[u][v] = 1;
        adjMatrix[v][u] = 1;
    }

    // DFS 수행 함수
    void DFS(int start, vector<bool>& visited) {
        visited[start] = true;
        for (int neighbor = 0; neighbor < vertices; ++neighbor) {
            if (adjMatrix[start][neighbor] && !visited[neighbor]) {
                DFS(neighbor, visited);
            }
        }
    }

    // 연결 성분 개수 구하기
    int countConnectedComponents() {
        int count = 0;
        vector<bool> visited(vertices, false);

        for (int i = 0; i < vertices; ++i) {
            if (!visited[i]) {
                DFS(i, visited);
                count++;
            }
        }

        return count;
    }
};

int main() {
    // 입력 받기
    int N;
    double p;

    cout << "양의 정수 N과 실수 확률값 p를 입력하세요: ";
    cin >> N >> p;

    // 난수 생성을 위한 시드 설정
    srand(time(0));

    // 그래프 생성 및 인접 행렬 생성
    Graph graph(N);

    // 확률을 이용하여 인접 행렬 생성
    for (int i = 0; i < N; ++i) {
        for (int j = i + 1; j < N; ++j) {
            double randValue = (double)rand() / RAND_MAX;
            if (randValue < p) {
                graph.addEdge(i, j);
            }
        }
    }

    // 인접리스트로 변환
    vector<vector<int>> adjList(N);
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            if (graph.adjMatrix[i][j]) {
                adjList[i].push_back(j);
            }
        }
    }

    // 연결 성분 개수 출력
    int connectedComponents = graph.countConnectedComponents();
    cout << "그래프의 연결 성분 개수: " << connectedComponents << endl;

    return 0;
}
