#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

// 그래프 클래스 정의
class Graph {
public:
    int vertices; // 정점의 개수
    vector<vector<int>> adjList; // 인접 리스트

    // 생성자
    Graph(int V) : vertices(V), adjList(V + 1) {}

    // 간선 추가 함수
    void addEdge(int u, int v) {
        adjList[u].push_back(v);
        adjList[v].push_back(u);
    }

    // DFS 수행 함수
    void DFS(int start, vector<bool>& visited) {
        cout << start << " ";
        visited[start] = true;
        for (int neighbor : adjList[start]) {
            if (!visited[neighbor]) {
                DFS(neighbor, visited);
            }
        }
    }

    // BFS 수행 함수
    void BFS(int start) {
        vector<bool> visited(vertices + 1, false);
        queue<int> q;

        q.push(start);
        visited[start] = true;

        while (!q.empty()) {
            int current = q.front();
            cout << current << " ";
            q.pop();

            for (int neighbor : adjList[current]) {
                if (!visited[neighbor]) {
                    q.push(neighbor);
                    visited[neighbor] = true;
                }
            }
        }
    }
};

int main() {
    // 입력 받기
    int vertices, edges;
    cout << "정점의 개수와 간선의 개수를 입력하세요: ";
    cin >> vertices >> edges;

    // 그래프 생성
    Graph graph(vertices);

    cout << "간선 정보를 입력하세요 (시작 정점과 도착 정점을 순서대로 입력):" << endl;
    for (int i = 0; i < edges; ++i) {
        int u, v;
        cin >> u >> v;
        graph.addEdge(u, v);
    }

    // DFS 수행 및 출력
    vector<bool> visitedDFS(vertices + 1, false);
    cout << "DFS: ";
    for (int i = 1; i <= vertices; ++i) {
        if (!visitedDFS[i]) {
            graph.DFS(i, visitedDFS);
        }
    }
    cout << endl;

    // BFS 수행 및 출력
    cout << "BFS: ";
    graph.BFS(1);
    cout << endl;

    return 0;
}
