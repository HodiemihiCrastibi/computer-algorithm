//문제4번
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <algorithm>
using namespace std;

#define infoNIL 0
#define itemMIN -1

typedef int itemType;
typedef double infoType;

void shuffle(int* b, int size) {
    vector<pair<int, int>> a(size);

    for (int i = 0; i < size; i++) {
        a[i].first = (1 + rand()) % size;
        a[i].second = b[i];
    }
    sort(a.begin(), a.end());
    // pair<int,int>의 정렬 기준: fisrt 오름차순, second 오름차순

    for (int i = 0; i < size; i++) {
        b[i] = a[i].second;
    }
}


class BST {
private:
    struct node {
        itemType key;
        infoType info;
        node* l, * r;

        node(itemType k, infoType i, node* ll, node* rr) {// node 생성시 초기값
            key = k; info = i; l = ll; r = rr;
        };

    };
    node* head, * z;   // z : List 의 끝을 대표하는 node pointer – NULL 에 해당
    int comparisons;



public:
    BST(int max) {
        // key info left right
        z = new node(0, infoNIL, 0, 0);
        head = new node(itemMIN, infoNIL, z, z);
        comparisons = 0;


    }

    ~BST() {
        deleteTree(head, z);
        delete z;

    }

    infoType BSTsearch(itemType v) {
        comparisons = 0;
        node* parent = head;


        while (1) {
            if (parent->key < v) {

                parent = parent->r;
                comparisons += 1;
                if (parent == z) {
                    return infoNIL;
                }
            }
            else if (parent->key > v) {
                parent = parent->l;
                comparisons += 1;
                if (parent == z) {
                    return infoNIL;
                }
            }
            else {
                comparisons += 1;
                return parent->info;
            }
        }
    }
    void BSTinsert(itemType v, infoType info) {
        node* parent = head;
        node* pastparent;

        while (1) {
            pastparent = parent;
            if (parent->key < v) {
                parent = parent->r;
                if (parent == z) {
                    node* newnode = new node(v, info, z, z);
                    pastparent->r = newnode;
                    break;
                }
            }
            else {
                parent = parent->l;
                if (parent == z) {
                    node* newnode = new node(v, info, z, z);
                    pastparent->l = newnode;
                    break;
                }
            }
        }
    }

    void deleteTree(node* t, node* z) {
        if (t != z) {
            deleteTree(t->l, z);
            deleteTree(t->r, z);
            delete t;
            
        }
    }

    int getComparisons() {
        return comparisons;
    }

    void visit(node* t, vector<pair<itemType, infoType>>& tr) {
        tr.push_back(make_pair(t->key, t->info));
    }

    void traverse(node* t, node* z, vector<pair<itemType, infoType>>& tr) {
        if (t != z) {
            traverse(t->l, z, tr);
            visit(t, tr);
            traverse(t->r, z, tr);
        }
    }

    void inordertraverse(vector<pair<itemType, infoType>>& tr) {
        traverse(head, z, tr);
    }

};





int main() {
    srand((unsigned)time(NULL));
    int N;
    cin >> N;
    int target;
    BST t1(N);
    int* numbers = new int[N];
    vector<pair<itemType, infoType>> traversalresult;

    for (int i = 0; i < N; i++) {

        numbers[i] = i;

    }
    shuffle(numbers, N);


    int cnt = 0;

    for (int i = 0; i < N; i++) {
        t1.BSTinsert(numbers[i], cnt++);
    }

    int comparisonst1 = 0;
    for (int i = 0; i < N; i++) {
        int rnd = rand() % N;
        t1.BSTsearch(rnd);
        comparisonst1 += t1.getComparisons();
    }

    cout << "random t1 : " << (double)comparisonst1 / (double)N << endl;

    t1.inordertraverse(traversalresult);



    BST t3(N);


    for (auto& p : traversalresult) {
        t3.BSTinsert(p.first, (double)p.second);
    }

    int comparisonst3 = 0;
    //for (int i = 0; i < N; i++) {
    //    int rnd = rand() % N;
    //    t3.BSTsearch(rnd);
    //    comparisonst3 += t3.getComparisons();
    //}
    for (int i = 0; i < N; i++) {
        int rnd = i;
        t3.BSTsearch(rnd);
        comparisonst3 += t3.getComparisons();
    }

    cout << "inorder t3 : " << (double)comparisonst3 / (double)N << endl;

    return 0;
}
