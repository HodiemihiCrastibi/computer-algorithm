//문제1
#include <iostream>
using namespace std;

struct treeNode {
    char info;
    treeNode *l, *r;
};



template<typename itemType>
class Stack {
private:
    itemType* stack;
    int p;
public:
    Stack(int max = 100) {
        stack = new itemType[max];
        p = 0;
    }
    ~Stack() {
        delete[] stack;
    }
    void push(itemType v) {
        stack[p++] = v;
    }
    itemType pop() {
        return stack[--p];
    }
    int empty() {
        return !p;
    }
};


void visit(treeNode* t) {
    cout << t->info << " ";
}

void traverse(treeNode* t, treeNode* z) {
    if (t != z) {
        traverse(t->l,z);
        visit(t);
        traverse(t->r,z);
    }
}

int main() {
    treeNode *x;
    treeNode* z = new treeNode;
    char c;
    Stack<treeNode*> stack(50);
    z->l = z;
    z->r = z;


    


    while ((c=cin.get()) != '\n') {
        if (c == ' ') continue;
        
        x = new treeNode;
        x->info = c;
        x->l = z;
        x->r = z;
        if (c == '+' || c == '*' || c == '-') {
            
            x->r = stack.pop();


            x->l = stack.pop();
        }
        stack.push(x);
    }
    traverse(stack.pop(),z);
    return 0;
}
