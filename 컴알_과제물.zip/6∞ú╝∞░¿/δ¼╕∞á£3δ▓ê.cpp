//문제3
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <algorithm>
using namespace std;

#define infoNIL 0
#define itemMIN -1

typedef int itemType;
typedef double infoType;

void shuffle(int* b, int size) {
    vector<pair<int, int>> a(size);

    for (int i = 0; i < size; i++) {
        a[i].first = (1 + rand()) % size;
        a[i].second = b[i];
    }
    sort(a.begin(), a.end());
    // pair<int,int>의 정렬 기준: fisrt 오름차순, second 오름차순

    for (int i = 0; i < size; i++) {
        b[i] = a[i].second;
    }
}


class BST {
private:
    struct node {
        itemType key;
        infoType info;
        node* l, * r;

        node(itemType k, infoType i, node* ll, node* rr) {// node 생성시 초기값
            key = k; info = i; l = ll; r = rr;
        };

    };
    node* head, * z;   // z : List 의 끝을 대표하는 node pointer – NULL 에 해당
    int comparisons;

public:
    BST(int max) {
        // key info left right
        z = new node(0, infoNIL, 0, 0);
        head = new node(itemMIN, infoNIL, z, z);
        comparisons = 0;
    }

    ~BST() {
        deleteTree(head, z);
        delete z;
    }

    infoType BSTsearch(itemType v) {
        comparisons = 0;
        node* parent = head;


        while (1) {
            if (parent->key < v) {

                parent = parent->r;
                comparisons += 1;
                if (parent == z) {
                    return infoNIL;
                }
            }
            else if (parent->key > v) {
                parent = parent->l;
                comparisons += 1;
                if (parent == z) {
                    return infoNIL;
                }
            }
            else {
                comparisons += 1;
                return parent->info;
            }
        }
    }
    void BSTinsert(itemType v, infoType info) {
        node* parent = head;
        node* pastparent;

        while (1) {
            pastparent = parent;
            if (parent->key < v) {
                parent = parent->r;
                if (parent == z) {
                    node* newnode = new node(v, info, z, z);
                    pastparent->r = newnode;
                    break;
                }
            }
            else {
                parent = parent->l;
                if (parent == z) {
                    node* newnode = new node(v, info, z, z);
                    pastparent->l = newnode;
                    break;
                }
            }
        }
    }

    void BSTdelete(itemType v) {
        node* parent = head;
        node* pastparent;
        node* least;
        node* pastleast;
        comparisons = 0;

        bool ispastparentrightsonparent = true;

        while (1) {
            
            if (parent->key < v) {
                comparisons += 1;
                ispastparentrightsonparent = true;
                pastparent = parent;
                parent = parent->r;
                if (parent == z) {
                    return;
                }
            }
            else if (parent->key > v) {
                comparisons += 1;


                ispastparentrightsonparent = false;
                pastparent = parent;
                parent = parent->l;
                if (parent == z) {
                    return;
                }
            }
            else {
                comparisons += 1;
                break;
            }
        }
        //키 평균 비교횟수... 키 이므로 세지 않는다.
        if (parent->r == z && parent->l == z) {
            //comparisons += 2;
            if (ispastparentrightsonparent) {

                pastparent->r = z;
                delete parent;
            }
            else {
                pastparent->l = z;
                delete parent;
            }
        }
        else if (parent->r == z) {
            //comparisons += 3;
            if (ispastparentrightsonparent) {
                pastparent->r = parent->l;
                delete parent;
            }
            else {
                pastparent->l = parent->l;
                delete parent;
            }
        }
        else if (parent->r != z && parent->r->l == z) {
            //comparisons += 5;
            if (ispastparentrightsonparent) {
                pastparent->r = parent->r;
                pastparent->r->l = parent->l;
                delete parent;
            }
            else {
                pastparent->l = parent->r;
                pastparent->l->l = parent->l;
                delete parent;
            }
        }
        else {
            //comparisons += 5;
            if (ispastparentrightsonparent) {
                least = parent->r;
                pastleast = parent;
                while (least->l != z) {
                    pastleast = least;
                    least = least->l;
                }
                pastleast->l = least->r;
                pastparent->r = least;
                least->l = parent->l;
                least->r = parent->r;
                delete parent;
            }
            else {
                least = parent->r;
                pastleast = parent;
                while (least->l != z) {
                    pastleast = least;
                    least = least->l;
                }
                pastleast->l = least->r;
                pastparent->l = least;
                least->l = parent->l;
                least->r = parent->r;
                delete parent;
            }
        }

        
    }


    void deleteTree(node* t, node* z) {
        if (t != z) {
            deleteTree(t->l, z);
            deleteTree(t->r, z);
            delete t;
        }
    }

    int getComparisons() {
        return comparisons;
    }

};





int main() {

    // N은 100이어야 합니다!!!!!
    srand((unsigned)time(NULL));
    int N;
    cin >> N;
    BST tree(N);
    int* numbers = new int[N];

    for (int i = 0; i < N; i++) {

        numbers[i] = i;

    }
    shuffle(numbers, N);


    int cnt = 0;

    for (int i = 0; i < N; i++) {
        tree.BSTinsert(numbers[i], cnt++);
    }

    int selector = rand() % 10; // 배열을 10개로 나누고 그중하나를 고르겠습니다.
    int numofdel = 3; // 30개의 노드를 삭제하겠습니다.

    int sumcomparisons = 0;
    for (int i = 0; i < numofdel; i++) {
        for (int j = selector; j < selector + 10; j++) {
     
            tree.BSTdelete(j);
            sumcomparisons += tree.getComparisons();
        }

        
    }

    cout << (double)sumcomparisons / (double)(numofdel*10) << endl;
    return 0;
}
