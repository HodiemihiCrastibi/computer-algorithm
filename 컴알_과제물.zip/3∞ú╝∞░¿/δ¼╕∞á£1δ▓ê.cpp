#include <iostream>
#include <algorithm>
#include <vector>
#include <time.h>
#include <stack>

using namespace std;

static long long compare_cnt = 0;
static long long datamove_cnt = 0;
static long long compare_cnt_a = 0;
static long long datamove_cnt_a = 0;

template <typename itemType>
void printarr(itemType a[], itemType b[], int n) {
    int i;
    cout << "SortedData_A" << ": ";
    for (i = 0; i < min(20, n); i++) {
        cout << a[i] << ' ';
    }
    cout << "\nSortedData_B" << ": ";
    for (i = 0; i < min(20, n); i++) {
        cout << b[i] << ' ';
    }
    cout << "\n" << "Compare_Cnt_A" << ": " << compare_cnt_a << ", DataMove_Cnt_A" << ": " << datamove_cnt_a << '\n';
    cout  << "Compare_Cnt_B" << ": " << compare_cnt << ", DataMove_Cnt_B" << ": " << datamove_cnt;
}

template <typename itemType>
inline void swap(itemType a[], int i, int j) {
    itemType t = a[i]; a[i] = a[j]; a[j] = t;
    datamove_cnt++;
}

template <typename itemType>
int partition(itemType a[], int l, int r) {
    int i, j; itemType v;
    if (r > l) {
        v = a[l]; i = l; j = r + 1;
        for (;;) {
            while (a[++i] < v) {
                compare_cnt++;
            }
            while (a[--j] > v) {
                compare_cnt++;
            }
            if (i >= j) break;
            swap(a, i, j);
        }
        swap(a, j, l);
    }
    return j;
}

template <typename itemType>
// gcc 에서는 오류가 없으나 vs환경에서는 stack overflow가 발생합니다.
// 따라서 일단 재귀를 안쓰고 스택을 이용하여 재구현 하였습니다.
//void quicksort(itemType a[], int l, int r) { 
//    int  j;
//    if (r > l) {
//        j = partition(a, l, r);
//        quicksort(a, l, j - 1);
//        quicksort(a, j + 1, r);
//    }
//}
void quicksort(itemType a[], int l, int r) {
    int j;
    stack<pair<int, int>> s;
    s.push(make_pair(l, r));
    while (!s.empty()) {
        pair<int, int> temp = s.top();
        s.pop();

        int l = temp.first;
        int r = temp.second;

        if (r > l) {
            j = partition(a, l, r);
            s.push(make_pair(l, j - 1));
            s.push(make_pair(j + 1, r));
        }
    }
}

int main() {
    int n;
    cout << "n: ";
    cin >> n;

    int* a = new int[n];
    int* b = new int[n];
    vector<vector<int>> temp(n);

    srand((unsigned)time(NULL));         // 현재시간을 이용해 난수발생기 rand()의 초기값을 재설정
    for (int i = 0; i < n; i++) {
        a[i] = n - i;
        temp[i] = vector<int>(2);
        temp[i][0] = (1 + rand() % n);            // 1~n 사이의 숫자 n개를 랜덤하게 생성
        temp[i][1] = i + 1;
    } // 난수가 만들어질 때마다 1씩 증가시켜가며 각 난수의 고유 인덱스를 생성
    sort(temp.begin(), temp.end());           // 난수 a[i][0]들을 정렬한 뒤 그 순서대로 인덱스 a[i][1]들을 나열시키면 B가 생성

    for (int i = 0; i < n; i++) {
        b[i] = temp[i][1];
    }

    quicksort(a, 0, n - 1);
    compare_cnt_a = compare_cnt;
    datamove_cnt_a = datamove_cnt;
    compare_cnt = 0;
    datamove_cnt = 0;
    quicksort(b, 0, n - 1);

    printarr(a, b, n);

    return 0;
}