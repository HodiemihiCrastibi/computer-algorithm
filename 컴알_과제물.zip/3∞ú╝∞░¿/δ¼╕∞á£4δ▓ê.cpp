#include <iostream>

using namespace std;

static long long comp_cnt = 0;

template <typename itemType>
inline void swap(itemType a[], int i, int j)
{
    itemType  t = a[i]; a[i] = a[j]; a[j] = t;
}

template <typename itemType>
class PQ {
private:
    itemType* a;
    int N;
public:
    PQ(int max)
    {
        a = new itemType[max]; N = 0;
    }
    ~PQ()
    {
        delete a;
    }

    void push(itemType var) {
        a[++N] = var;
    }

    void printHeap() {
        for (int i = 1; i <= min(N, 20); i++) {
            cout << a[i] << ' ';
        }
        cout << '\n';
    }

    void HeapifyDown(int Root, int LastNode) { // heap에 삽입하는 과정
        int start, next;
        start = Root;

        while (start <= LastNode / 2) {
            if (start * 2 + 1 <= LastNode) {
                comp_cnt++;
                if (a[start] < a[2 * start] && a[start] < a[2 * start + 1]) {
                    if (a[2 * start] > a[2 * start + 1]) next = 2 * start;
                    else next = 2 * start + 1;
                }
                else if (a[start] < a[2 * start]) {
                    next = 2 * start;
                }
                else if (a[start] < a[2 * start + 1]) {
                    next = 2 * start + 1;
                }
                else break;

                swap(a, start, next);
                start = next;
            }
            else {
                comp_cnt++;
                if (a[start] < a[2 * start]) {
                    next = 2 * start;
                }
                else break;

                swap(a, start, next);
                start = next;
            }
        }            
    }

    void HeapifyUp(int Root, int LastNode) { // heap에서 원소를 삭제하는 과정
        int start, next;
        start = LastNode;

        while (start / 2 >= Root) {
            comp_cnt++;
            if (a[start / 2] < a[start]) {
                swap(a, start / 2, start);
                start /= 2;
            }
            else break;
        }

    }
    
    void heapsort(itemType arr[], int N) {
        int i;
        for (i = 1; i < N + 1; i++) {
            push(arr[i]); // arr 값 들을 heap에 삽입
        }

        for (i = N; i >= 1; i--) {
            HeapifyUp(1, i); // arr 힙으로 만들기
        }
        cout << '\n';
;        for (i = N; i > 1; i--) {
            swap(a, 1, i); // 맨 뒤와 맨 앞 원소 교환
            HeapifyDown(1, i - 1); // 마지막 원소 제외하고 다시 힙으로 만들기
        }
        cout << "Sorted_arr: ";
        printHeap();
    }
};

int main() {
    int n;
    cout << "n: ";
    cin >> n;
    PQ<int> heap(n + 1);
    int* a = new int[n + 1];

    for (int i = 1; i < n + 1; i++) a[i] = i;
    heap.heapsort(a, n);
    cout << "Comp_count: " << comp_cnt;
    
    return 0;
}
