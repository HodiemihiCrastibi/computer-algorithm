#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <algorithm>
#include <string>
#include <cstring>
#include <fstream>
#include <vector>
#include <map>

using namespace std;

char special[7] = { '.', ',', '/', ' ', ';', ':', '\n' };
vector<char*> words = {};
map<string, int> result;


bool comp(pair<string, int> a, pair<string, int> b) {
    if (result[a.first] == result[b.first]) {
        return strcmp(a.first.c_str(), b.first.c_str()) < 0; // a 가 b 보다 순서가 빠른지 확인한 값을 리턴
    }
    else {
        return result[a.first.c_str()] > result[b.first.c_str()]; //a가 b보다 빈도수가 더 큰지 확인한 값을 리턴
    }
}

int main() {
    string line;
    bool isSpecial = false;
    ifstream file("./datafile.txt"); // 파일 읽어오기
    string temp("");
    if (file.is_open()) {
        while (getline(file, line)) { // 파일 문자 '\n' 만날때까지 읽어옴
            int i = 0;
            temp.clear();
            char* t = NULL;
            while (i < line.length()) {
                for (int j = 0; j < 7; j++) {
                    if (line[i] == special[j]) { // 특수문자가 있으면
                        if (temp.size() > 0) { // temp에 저장된 문자열 words에 저장
                            t = new char[temp.size() + 1];
                            strcpy(t, temp.c_str());
                            words.push_back(t);
                            temp.clear(); // 초기화
                        }
                        isSpecial = true;
                        break;
                    }
                }
                if (!isSpecial) { // 현재 인덱스의 문자가 특수문자가 아니면 temp에 문자 추가
                    temp = temp + line.at(i);
                }
                isSpecial = false;
                i++;
            }
            if (temp.size() > 0) {
                t = new char[temp.size() + 1];
                strcpy(t, temp.c_str());
                words.push_back(t);
            }
        }
        file.close();
    }
    else {
        cout << "error\n";
        return 1;
    }

    for (int i = 0; i < words.size(); i++) { // 빈도수 계산
        if (result.count(words[i]) == 0) {
            result[words[i]] = 1;
        }
        else {
            result[words[i]] += 1;
        }
    }

    vector<pair<string, int>> res(result.begin(), result.end());
    sort(res.begin(), res.end(), comp);


    for (const auto &i: res) {
        cout << i.first << ": " << i.second << '\n';
    }

    return 0;
}