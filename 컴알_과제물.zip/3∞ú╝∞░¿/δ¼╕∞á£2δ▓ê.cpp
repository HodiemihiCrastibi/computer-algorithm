#include <iostream>
#include <algorithm>
#include <vector>
#include <time.h>

using namespace std;

static long long compare_cnt = 0;
static long long datamove_cnt = 0;
static long long compare_cnt_a = 0;
static long long datamove_cnt_a = 0;
int n;

template <typename itemType>
itemType* sorted = new itemType[n];

template <typename itemType>
void printarr(itemType a[], itemType b[], int n) {
    int i;
    cout << "SortedData_A" << ": ";
    for (i = 0; i < min(20, n); i++) {
        cout << a[i] << ' ';
    }
    cout << "\nSortedData_B" << ": ";
    for (i = 0; i < min(20, n); i++) {
        cout << b[i] << ' ';
    }
    cout << "\n" << "Compare_Cnt_A"<< ": " << compare_cnt_a << ", DataMove_Cnt_A" << ": " << datamove_cnt_a << '\n';
    cout << "Compare_Cnt_B" << ": " << compare_cnt << ", DataMove_Cnt_B" << ": " << datamove_cnt << '\n';
}

template <typename itemType>
void merge(itemType a[], int l, int mid, int r) {
    itemType* sorted = new itemType[n];
    int i, j, k, n;
    i = l; j = mid + 1; k = l;
    while (i <= mid && j <= r) {
        compare_cnt++;
        if (a[i] <= a[j]) {
            datamove_cnt++;
            sorted[k++] = a[i++];
        }
        else {
            datamove_cnt++;
            sorted[k++] = a[j++];
        }
    }
    if (i > mid)
        for (n = j; n <= r; n++) {
            sorted[k++] = a[n];
            datamove_cnt++;
        }
    else
        for (n = i; n <= mid; n++) {
            sorted[k++] = a[n];
            datamove_cnt++;
        }
    for (n = l; n <= r; n++) {
        a[n] = sorted[n];
    }
}

template <typename itemType>
void mergesort(itemType a[], int l, int r) {
    int mid;
    if (l < r) {
        mid = (l + r) / 2;
        mergesort(a, l, mid);
        mergesort(a, mid + 1, r);
        merge(a, l, mid, r);
    }
}

int main() {
    cout << "n: ";
    cin >> n;

    int* a = new int[n];
    int* b = new int[n];
    vector<vector<int>> temp(n);

    srand((unsigned)time(NULL)); // 현재시간을 이용해 난수발생기 rand()의 초기값을 재설정
    for (int i = 0; i < n; i++) {
        a[i] = n - i;
        temp[i] = vector<int>(2);
        temp[i][0] = (1 + rand() % n); // 1~n 사이의 숫자 n개를 랜덤하게 생성
        temp[i][1] = i + 1;
    } // 난수가 만들어질 때마다 1씩 증가시켜가며 각 난수의 고유 인덱스를 생성
    sort(temp.begin(), temp.end()); // 난수 a[i][0]들을 정렬한 뒤 그 순서대로 인덱스 a[i][1]들을 나열시키면 B가 생성
    for (int i = 0; i < n; i++) {
        b[i] = temp[i][1];
    }

    mergesort(a, 0, n - 1);
    compare_cnt_a = compare_cnt;
    datamove_cnt_a = datamove_cnt;
    compare_cnt = 0;
    datamove_cnt = 0;
    mergesort(b, 0, n - 1);

    printarr(a, b, n);

    return 0;
}