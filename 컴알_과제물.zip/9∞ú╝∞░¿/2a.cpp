#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

// 함수 선언
void find_max_subarray_bruteforce(const vector<int>& arr, int& comparisons);
void find_max_subarray_divide_and_conquer(const vector<int>& arr, int low, int high, int& comparisons);

// Bruteforce 방법으로 최대 부분 배열 찾기
void find_max_subarray_bruteforce(const vector<int>& arr, int& comparisons) {
    int n = arr.size();
    comparisons = 0;

    for (int i = 0; i < n; ++i) {
        int current_sum = 0;
        for (int j = i; j < n; ++j) {
            current_sum += arr[j];
            comparisons++;
        }
    }
}

// Divide-and-Conquer 방법으로 최대 부분 배열 찾기 (수정된 버전)
void find_max_subarray_divide_and_conquer(const vector<int>& arr, int low, int high, int& comparisons) {
    int n = arr.size();
    int baseCaseThreshold = 10; // 기준 임계값 (임의의 값, 조절 가능)

    if (high - low + 1 <= baseCaseThreshold) {
        find_max_subarray_bruteforce(arr, comparisons);
    }
    else {
        int mid = (low + high) / 2;
        int left_comparisons, right_comparisons;

        find_max_subarray_divide_and_conquer(arr, low, mid, left_comparisons);
        find_max_subarray_divide_and_conquer(arr, mid + 1, high, right_comparisons);

        comparisons += left_comparisons + right_comparisons;
    }
}

// 최대 입력 크기 N에서 Bruteforce와 Divide-and-Conquer의 비교 횟수를 구하는 함수
void find_maximum_n(int& maxN, int& bruteforce_comparisons, int& divide_and_conquer_comparisons) {
    int step = 5;

    for (int N = 1; N <= maxN; N += step) {
        vector<int> arr(N, 1);  // N 크기의 배열, 모든 원소를 1로 초기화
        int bf_comparisons, dc_comparisons;

        find_max_subarray_bruteforce(arr, bf_comparisons);
        find_max_subarray_divide_and_conquer(arr, 0, arr.size() - 1, dc_comparisons);

        if (bf_comparisons <= dc_comparisons) {
            maxN = N;
            bruteforce_comparisons = bf_comparisons;
            divide_and_conquer_comparisons = dc_comparisons;
        }
    }
}

// 그래프를 생성하는 함수
void generate_graph_data(const string& filename, int maxN) {
    ofstream outputFile;
    outputFile.open(filename);

    outputFile << "N,Bruteforce Comparisons,Divide-and-Conquer Comparisons\n";

    for (int N = 1; N <= maxN; ++N) {
        vector<int> arr(N, 1);  // N 크기의 배열, 모든 원소를 1로 초기화
        int bruteforce_comparisons, divide_and_conquer_comparisons;

        find_max_subarray_bruteforce(arr, bruteforce_comparisons);
        find_max_subarray_divide_and_conquer(arr, 0, arr.size() - 1, divide_and_conquer_comparisons);

        outputFile << N << "," << bruteforce_comparisons << "," << divide_and_conquer_comparisons << "\n";
    }

    outputFile.close();
    cout << "Graph data saved to " << filename << endl;
}

int main() {
    int maxN = 100;  // 초기 최대 N값 설정
    int bruteforce_comparisons, divide_and_conquer_comparisons;

    // Bruteforce 방법의 비교 횟수가 Divide-and-Conquer보다 작거나 같아지는 최대 N 구하기
    find_maximum_n(maxN, bruteforce_comparisons, divide_and_conquer_comparisons);

    // 결과 출력
    cout << "Bruteforce Comparisons: " << bruteforce_comparisons << endl;
    cout << "Divide-and-Conquer Comparisons: " << divide_and_conquer_comparisons << endl;
    cout << "Maximum N for Bruteforce <= Divide-and-Conquer: " << maxN << endl;


    return 0;
}
