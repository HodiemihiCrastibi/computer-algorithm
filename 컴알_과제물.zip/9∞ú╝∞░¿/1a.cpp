#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

// 함수 선언
void find_max_subarray_bruteforce(const vector<int>& arr, int& start, int& end, int& max_sum, int& comparisons);
void find_max_subarray_divide_and_conquer(const vector<int>& arr, int low, int high, int& start, int& end, int& max_sum, int& comparisons);
void find_max_subarray_dynamic_programming(const vector<int>& arr, int& start, int& end, int& max_sum, int& comparisons);
void find_max_crossing_subarray(const vector<int>& arr, int low, int mid, int high, int& start, int& end, int& max_sum, int& comparisons);

// Bruteforce 방법으로 최대 부분 배열 찾기
void find_max_subarray_bruteforce(const vector<int>& arr, int& start, int& end, int& max_sum, int& comparisons) {
    int n = arr.size();
    max_sum = INT_MIN;

    for (int i = 0; i < n; ++i) {
        int current_sum = 0;
        for (int j = i; j < n; ++j) {
            current_sum += arr[j];
            comparisons++;
            if (current_sum > max_sum) {
                max_sum = current_sum;
                start = i;
                end = j;
            }
        }
    }
}

// Divide-and-Conquer 방법으로 최대 부분 배열 찾기 (수정된 버전)
void find_max_subarray_divide_and_conquer(const vector<int>& arr, int low, int high, int& start, int& end, int& max_sum, int& comparisons) {
    int n = arr.size();
    int baseCaseThreshold = 10; // 기준 임계값 (임의의 값, 조절 가능)

    if (high - low + 1 <= baseCaseThreshold) {
        find_max_subarray_bruteforce(arr, start, end, max_sum, comparisons);
    }
    else {
        int mid = (low + high) / 2;
        int left_start, left_end, left_sum, left_comparisons;
        int right_start, right_end, right_sum, right_comparisons;
        int cross_start, cross_end, cross_sum, cross_comparisons;

        find_max_subarray_divide_and_conquer(arr, low, mid, left_start, left_end, left_sum, left_comparisons);
        find_max_subarray_divide_and_conquer(arr, mid + 1, high, right_start, right_end, right_sum, right_comparisons);
        find_max_crossing_subarray(arr, low, mid, high, cross_start, cross_end, cross_sum, cross_comparisons);

        if (left_sum >= right_sum && left_sum >= cross_sum) {
            start = left_start;
            end = left_end;
            max_sum = left_sum;
            comparisons = left_comparisons + right_comparisons + cross_comparisons;
        }
        else if (right_sum >= left_sum && right_sum >= cross_sum) {
            start = right_start;
            end = right_end;
            max_sum = right_sum;
            comparisons = left_comparisons + right_comparisons + cross_comparisons;
        }
        else {
            start = cross_start;
            end = cross_end;
            max_sum = cross_sum;
            comparisons = left_comparisons + right_comparisons + cross_comparisons;
        }
    }
}

// Divide-and-Conquer 방법에서의 최대 교차 부분 배열 찾기
void find_max_crossing_subarray(const vector<int>& arr, int low, int mid, int high, int& start, int& end, int& max_sum, int& comparisons) {
    int left_sum = INT_MIN;
    int sum = 0;
    comparisons = 0; // 초기화
    for (int i = mid; i >= low; --i) {
        sum += arr[i];
        comparisons++;
        if (sum > left_sum) {
            left_sum = sum;
            start = i;
        }
    }

    int right_sum = INT_MIN;
    sum = 0;
    for (int i = mid + 1; i <= high; ++i) {
        sum += arr[i];
        comparisons++;
        if (sum > right_sum) {
            right_sum = sum;
            end = i;
        }
    }

    max_sum = left_sum + right_sum;
}

// Dynamic Programming 방법으로 최대 부분 배열 찾기
void find_max_subarray_dynamic_programming(const vector<int>& arr, int& start, int& end, int& max_sum, int& comparisons) {
    int n = arr.size();
    int current_sum = arr[0]; // 초기값을 첫 번째 원소로 설정
    max_sum = arr[0];
    start = 0;

    for (int i = 1; i < n; ++i) {
        comparisons++;
        if (current_sum <= 0) {
            start = i;
            current_sum = arr[i];
        }
        else {
            current_sum += arr[i];
        }

        if (current_sum > max_sum) {
            end = i;
            max_sum = current_sum;
        }
    }
}

// 입력 크기 N에 대한 그래프 데이터 생성
void generate_graph_data(const string& filename, int maxN) {
    ofstream outfile(filename);

    outfile << "N,BruteforceComparisons,DivideAndConquerComparisons" << endl;

    for (int N = 1; N <= maxN; ++N) {
        // 벡터 초기화 및 랜덤 값 할당
        vector<int> arr(N);
        for (int i = 0; i < N; ++i) {
            arr[i] = rand() % 100 - 50; // -50에서 49 사이의 랜덤 값
        }

        // 방법 1: Brute-force
        int start1, end1, max_sum1, comparisons1 = 0;
        find_max_subarray_bruteforce(arr, start1, end1, max_sum1, comparisons1);

        // 방법 2: Divide-and-Conquer
        int start2, end2, max_sum2, comparisons2 = 0;
        find_max_subarray_divide_and_conquer(arr, 0, arr.size() - 1, start2, end2, max_sum2, comparisons2);

        // 결과 기록
        outfile << N << "," << comparisons1 << "," << comparisons2 << endl;
    }

    outfile.close();
}

int find_maximum_n() {
    int maxN = 1;
    int bruteforce_comparisons, divide_and_conquer_comparisons;

    do {
        maxN *= 2;

        // 벡터 초기화 및 랜덤 값 할당
        vector<int> arr(maxN);
        for (int i = 0; i < maxN; ++i) {
            arr[i] = rand() % 100 - 50; // -50에서 49 사이의 랜덤 값
        }

        // 방법 1: Brute-force
        int start1, end1, max_sum1, comparisons1 = 0;
        find_max_subarray_bruteforce(arr, start1, end1, max_sum1, comparisons1);

        // 방법 2: Divide-and-Conquer
        int start2, end2, max_sum2, comparisons2 = 0;
        find_max_subarray_divide_and_conquer(arr, 0, arr.size() - 1, start2, end2, max_sum2, comparisons2);

        bruteforce_comparisons = comparisons1;
        divide_and_conquer_comparisons = comparisons2;

    } while (bruteforce_comparisons > divide_and_conquer_comparisons);

    return maxN;
}


    int main() {
        // 입력 예제 배열
        vector<int> arr = { 1, 1, 1, -3, 1, 1, 1, -3, 1, 1, 1, -3, 1, 1, 1, -3};

        // 방법 1: Brute-force
        int start1, end1, max_sum1, comparisons1 = 0;
        find_max_subarray_bruteforce(arr, start1, end1, max_sum1, comparisons1);
        cout << "Bruteforce 결과: subarray 위치 = [" << start1 << ", " << end1 << "], 합 = " << max_sum1 << ", 비교횟수 = " << comparisons1 << endl;

        // 방법 2: Divide-and-Conquer
        int start2, end2, max_sum2, comparisons2 = 0;
        find_max_subarray_divide_and_conquer(arr, 0, arr.size() - 1, start2, end2, max_sum2, comparisons2);
        cout << "Divide-and-Conquer 결과: subarray 위치 = [" << start2 << ", " << end2 << "], 합 = " << max_sum2 << ", 비교횟수 = " << comparisons2 << endl;

        // 방법 3: Dynamic Programming
        int start3, end3, max_sum3, comparisons3 = 0;
        find_max_subarray_dynamic_programming(arr, start3, end3, max_sum3, comparisons3);
        cout << "Dynamic Programming 결과: subarray 위치 = [" << start3 << ", " << end3 << "], 합 = " << max_sum3 << ", 비교횟수 = " << comparisons3 << endl;

        return 0;
}
