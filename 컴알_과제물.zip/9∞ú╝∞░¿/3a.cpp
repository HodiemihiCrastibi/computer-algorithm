#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

// 동적 프로그래밍을 이용한 강좌 선택
void course_selection_dynamic_programming(const vector<int>& s, const vector<int>& f, vector<int>& selected_courses, int& comparisons) {
    int n = s.size();

    // 종료 시간 기준으로 정렬
    vector<pair<int, int>> courses;
    for (int i = 0; i < n; ++i) {
        courses.push_back({ f[i], i });
    }
    sort(courses.begin(), courses.end());

    // 동적 프로그래밍을 위한 배열 초기화
    vector<int> dp(n, 1);
    vector<int> prev(n, -1);

    // 동적 프로그래밍
    for (int i = 1; i < n; ++i) {
        for (int j = 0; j < i; ++j) {
            comparisons++;
            if (f[courses[j].second] <= s[courses[i].second] && dp[i] < dp[j] + 1) {
                dp[i] = dp[j] + 1;
                prev[i] = j;
            }
        }
    }

    // 최대 길이 부분 수열 추적
    int max_length = 0;
    int end_index = 0;
    for (int i = 0; i < n; ++i) {
        comparisons++;
        if (max_length < dp[i]) {
            max_length = dp[i];
            end_index = i;
        }
    }

    // 결과 저장
    selected_courses.clear();
    while (end_index != -1) {
        selected_courses.push_back(courses[end_index].second);
        end_index = prev[end_index];
    }

    reverse(selected_courses.begin(), selected_courses.end());
}

// 그리디 알고리즘을 이용한 강좌 선택
void course_selection_greedy_algorithm(const vector<int>& s, const vector<int>& f, vector<int>& selected_courses, int& comparisons) {
    int n = s.size();

    // 종료 시간을 기준으로 정렬
    vector<pair<int, int>> courses;
    for (int i = 0; i < n; ++i) {
        courses.push_back({ f[i], i });
    }
    sort(courses.begin(), courses.end());

    // 첫 번째 강좌 선택
    int last_finish_time = courses[0].first;
    selected_courses.push_back(courses[0].second);

    // 그리디 알고리즘 수행
    for (int i = 1; i < n; ++i) {
        comparisons++;
        if (s[courses[i].second] >= last_finish_time) {
            last_finish_time = courses[i].first;
            selected_courses.push_back(courses[i].second);
        }
    }
}

int main() {
    // 입력 예제
    vector<int> s = { 1, 3, 0, 5, 3, 5, 6, 8, 8, 2, 1 };
    vector<int> f = { 4, 5, 6, 7, 9, 9, 10, 11, 12, 14, 16 };

    // 결과 저장을 위한 벡터
    vector<int> selected_courses;

    // 비교 횟수 초기화
    int comparisons_dp = 0;
    int comparisons_greedy = 0;

    // 동적 프로그래밍을 이용한 강좌 선택
    course_selection_dynamic_programming(s, f, selected_courses, comparisons_dp);
    cout << "Dynamic Programming 결과: 강좌 = ";
    for (int course : selected_courses) {
        cout << course << " ";
    }
    cout << ", 비교횟수 = " << comparisons_dp << endl;

    // 그리디 알고리즘을 이용한 강좌 선택
    selected_courses.clear();
    course_selection_greedy_algorithm(s, f, selected_courses, comparisons_greedy);
    cout << "Greedy Algorithm 결과: 강좌 = ";
    for (int course : selected_courses) {
        cout << course << " ";
    }
    cout << ", 비교횟수 = " << comparisons_greedy << endl;

    return 0;
}
