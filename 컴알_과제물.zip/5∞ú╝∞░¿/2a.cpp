#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

#define infoNIL 0
#define itemMIN -1
typedef int itemType;
typedef double infoType;

class BST {
private:
    struct node {
        itemType key;      // 노드의 키 값
        infoType info;     // 노드의 정보 값
        struct node* l;    // 왼쪽 자식 노드
        struct node* r;    // 오른쪽 자식 노드
        int comparisons;   // 삽입 시 비교 횟수를 추적
        node(itemType k, infoType i, struct node* ll, struct node* rr)
            : key(k), info(i), l(ll), r(rr), comparisons(0) {}
    };
    struct node* head;     // 헤드 노드
    struct node* z;        // NIL 노드
    int totalComparisons;  // 전체 비교 횟수를 추적

public:
    BST(int max) {
        z = new node(0, infoNIL, 0, 0);
        head = new node(itemMIN, infoNIL, z, z);
        totalComparisons = 0;
    }

    ~BST() {
        // 소멸자 구현 필요시 추가
    }

    infoType BSTsearch(itemType v) {
        return searchRecursive(head->r, v);
    }

    void BSTinsert(itemType v, infoType info) {
        insertRecursive(head, v, info);
    }

    double getAverageComparisons() {
        if (totalComparisons == 0) {
            return 0.0;
        }
        int totalNodes = head->r->comparisons; // 총 삽입된 노드 수
        return static_cast<double>(totalComparisons) / totalNodes;
    }

private:
    infoType searchRecursive(struct node* x, itemType v) {
        if (x == z) {
            return infoNIL;
        }
        else if (v == x->key) {
            return x->info;
        }
        else if (v < x->key) {
            return searchRecursive(x->l, v);
        }
        else {
            return searchRecursive(x->r, v);
        }
    }

    void insertRecursive(struct node* x, itemType v, infoType info) {
        if (x == z) {
            x = new node(v, info, z, z);
            totalComparisons += x->comparisons;
        }
        else if (v == x->key) {
            x->info = info; // 이미 존재하는 키의 경우 정보 업데이트
        }
        else {
            x->comparisons++; // 삽입 중 비교 횟수 증가
            totalComparisons++; // 전체 비교 횟수 증가
            if (v < x->key) {
                if (x->l == z) {
                    x->l = new node(v, info, z, z);
                    totalComparisons += x->l->comparisons;
                }
                else {
                    insertRecursive(x->l, v, info);
                }
            }
            else {
                if (x->r == z) {
                    x->r = new node(v, info, z, z);
                    totalComparisons += x->r->comparisons;
                }
                else {
                    insertRecursive(x->r, v, info);
                }
            }
        }
    }
};

int main() {
    BST binarySearchTree(10000); // 최대 10000개 노드를 가진 이진 검색 트리 생성

    // 난수 생성기 초기화
    std::srand(static_cast<unsigned>(std::time(0)));

    int N = 100; // 무작위 값의 개수

    // N개의 무작위 값 생성하여 이진 검색 트리에 삽입
    for (int i = 0; i < N; i++) {
        int randomValue = std::rand() % 9901 + 100; // 100부터 10000까지의 난수 생성
        binarySearchTree.BSTinsert(randomValue, 0.0);
    }

    double averageComparisons = binarySearchTree.getAverageComparisons();

    std::cout << N << "개의 무작위 키에 대한 평균 비교 횟수: " << averageComparisons << std::endl;

    return 0;
}

