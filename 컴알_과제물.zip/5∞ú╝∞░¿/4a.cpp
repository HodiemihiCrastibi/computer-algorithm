#include <iostream>
#include <ctime>
#include <cstdlib>
#include <vector>

using namespace std;

#define infoNIL 0
#define itemMIN -1
typedef int itemType;
typedef double infoType;

class BST {
private:
    struct node {
        itemType key;
        infoType info;
        struct node* l;
        struct node* r;
        int comparisons;
        node(itemType k, infoType i, struct node* ll, struct node* rr)
            : key(k), info(i), l(ll), r(rr), comparisons(0) {}
    };
    struct node* head;
    struct node* z;
    int totalComparisons;

public:
    BST(int max) {
        z = new node(0, infoNIL, 0, 0);
        head = new node(itemMIN, infoNIL, z, z);
        totalComparisons = 0;
    }

    ~BST() {
        // Implement destructor if needed
    }

    infoType BSTsearch(itemType v) {
        return searchRecursive(head->r, v);
    }

    void BSTinsert(itemType v, infoType info) {
        insertRecursive(head, v, info);
    }

    double getAverageComparisons() {
        if (totalComparisons == 0) {
            return 0.0;
        }
        int totalNodes = head->r->comparisons;
        return static_cast<double>(totalComparisons) / totalNodes;
    }

    void InorderTraversal(vector<itemType>& data) {
        InorderRecursive(head->r, data);
    }

private:
    infoType searchRecursive(struct node* x, itemType v) {
        if (x == z) {
            return infoNIL;
        }
        else if (v == x->key) {
            return x->info;
        }
        else if (v < x->key) {
            return searchRecursive(x->l, v);
        }
        else {
            return searchRecursive(x->r, v);
        }
    }

    void insertRecursive(struct node* x, itemType v, infoType info) {
        if (x == z) {
            x = new node(v, info, z, z);
            totalComparisons += x->comparisons;
        }
        else if (v == x->key) {
            x->info = info;
        }
        else {
            x->comparisons++;
            totalComparisons++;
            if (v < x->key) {
                if (x->l == z) {
                    x->l = new node(v, info, z, z);
                    totalComparisons += x->l->comparisons;
                }
                else {
                    insertRecursive(x->l, v, info);
                }
            }
            else {
                if (x->r == z) {
                    x->r = new node(v, info, z, z);
                    totalComparisons += x->r->comparisons;
                }
                else {
                    insertRecursive(x->r, v, info);
                }
            }
        }
    }

    void InorderRecursive(struct node* x, vector<itemType>& data) {
        if (x != z) {
            InorderRecursive(x->l, data);
            data.push_back(x->key);
            InorderRecursive(x->r, data);
        }
    }
};

int main() {
    BST T1(10000);

    std::srand(static_cast<unsigned>(std::time(0)));

    int N;
    cout << "N을 입력하세요: ";
    cin >> N;

    if (N < 100) {
        cout << "N은 100 이상이어야 합니다." << endl;
        return 1;
    }

    vector<int> randomValues;

    for (int i = 0; i < N; i++) {
        int randomValue;
        do {
            randomValue = std::rand() % (N * 2);
        } while (find(randomValues.begin(), randomValues.end(), randomValue) != randomValues.end());
        randomValues.push_back(randomValue);
        T1.BSTinsert(randomValue, 0.0);
    }

    vector<int> inorderData;
    T1.InorderTraversal(inorderData);

    // 새로운 T3 트리 생성
    BST T3(10000);
    for (int value : inorderData) {
        T3.BSTinsert(value, 0.0);
    }

    double avgComparisonsT1 = T1.getAverageComparisons();
    double avgComparisonsT3 = T3.getAverageComparisons();

    cout << "T1의 평균 비교 횟수: " << avgComparisonsT1 << endl;
    cout << "T3의 평균 비교 횟수: " << avgComparisonsT3 << endl;

    if (avgComparisonsT1 < avgComparisonsT3) {
        cout << "T1이 T3보다 더 효율적인 탐색 성능을 갖습니다." << endl;
    }
    else if (avgComparisonsT1 > avgComparisonsT3) {
        cout << "T3이 T1보다 더 효율적인 탐색 성능을 갖습니다." << endl;
    }
    else {
        cout << "T1과 T3의 탐색 성능은 동일합니다." << endl;
    }

    return 0;
}
