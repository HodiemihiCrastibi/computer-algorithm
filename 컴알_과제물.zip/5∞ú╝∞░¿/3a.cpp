#include <iostream>
#include <ctime>
#include <cstdlib>
#include <vector>

using namespace std;

#define infoNIL 0
#define itemMIN -1
typedef int itemType;
typedef double infoType;

class BST {
private:
    struct node {
        itemType key;          // 노드의 키 값
        infoType info;         // 노드의 정보 값
        struct node* l;        // 왼쪽 자식 노드
        struct node* r;        // 오른쪽 자식 노드
        int comparisons;       // 삽입 시 비교 횟수를 추적
        node(itemType k, infoType i, struct node* ll, struct node* rr)
            : key(k), info(i), l(ll), r(rr), comparisons(0) {}
    };
    struct node* head;         // 헤드 노드
    struct node* z;            // NIL 노드
    int totalComparisons;      // 전체 비교 횟수를 추적

public:
    BST(int max) {
        z = new node(0, infoNIL, 0, 0);
        head = new node(itemMIN, infoNIL, z, z);
        totalComparisons = 0;
    }

    ~BST() {
        // 필요시 소멸자 구현
    }

    infoType BSTsearch(itemType v) {
        return searchRecursive(head->r, v);
    }

    void BSTinsert(itemType v, infoType info) {
        insertRecursive(head, v, info);
    }

    void BSTdelete(itemType v) {
        deleteRecursive(head, v);
    }

    double getAverageComparisons() {
        if (totalComparisons == 0) {
            return 0.0;
        }
        int totalNodes = head->r->comparisons;
        return static_cast<double>(totalComparisons) / totalNodes;
    }

private:
    infoType searchRecursive(struct node* x, itemType v) {
        if (x == z) {
            return infoNIL;
        }
        else if (v == x->key) {
            return x->info;
        }
        else if (v < x->key) {
            return searchRecursive(x->l, v);
        }
        else {
            return searchRecursive(x->r, v);
        }
    }

    void insertRecursive(struct node* x, itemType v, infoType info) {
        if (x == z) {
            x = new node(v, info, z, z);
            totalComparisons += x->comparisons;
        }
        else if (v == x->key) {
            x->info = info;
        }
        else {
            x->comparisons++;
            totalComparisons++;
            if (v < x->key) {
                if (x->l == z) {
                    x->l = new node(v, info, z, z);
                    totalComparisons += x->l->comparisons;
                }
                else {
                    insertRecursive(x->l, v, info);
                }
            }
            else {
                if (x->r == z) {
                    x->r = new node(v, info, z, z);
                    totalComparisons += x->r->comparisons;
                }
                else {
                    insertRecursive(x->r, v, info);
                }
            }
        }
    }

    void deleteRecursive(struct node* x, itemType v) {
        // 이 함수는 이진 탐색 트리에서 키 'v'를 가진 노드를 삭제해야 합니다.
    }
};

int main() {
    BST binarySearchTree(10000);

    std::srand(static_cast<unsigned>(std::time(0)));

    int N;
    cout << "N을 입력하세요 (100 이상): ";
    cin >> N;

    if (N < 100) {
        cout << "N은 100 이상이어야 합니다." << endl;
        return 1;
    }

    vector<int> randomValues;

    for (int i = 0; i < N; i++) {
        int randomValue;
        do {
            randomValue = std::rand() % 9901 + 100;
        } while (find(randomValues.begin(), randomValues.end(), randomValue) != randomValues.end());
        randomValues.push_back(randomValue);
        binarySearchTree.BSTinsert(randomValue, 0.0);
    }

    double totalComparisons = 0;

    for (int i = 0; i < N / 10; i++) {
        for (int j = 0; j < 10; j++) {
            if (randomValues.empty()) {
                break;
            }
            int randomIndex = std::rand() % randomValues.size();
            int randomValue = randomValues[randomIndex];
            binarySearchTree.BSTdelete(randomValue);
            randomValues.erase(randomValues.begin() + randomIndex);
        }
        double averageComparisons = binarySearchTree.getAverageComparisons();
        if (averageComparisons != 0.0) {
            totalComparisons += averageComparisons;
        }
    }

    if (totalComparisons != 0) {
        double finalAverage = totalComparisons / (N / 10);
        cout << "평균 비교 횟수: " << static_cast<int>(finalAverage) << endl;
    }
    else {
        cout << "모든 값이 삭제되었거나 삭제 연산이 수행되지 않았습니다." << endl;
    }

    return 0;
}
