#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <climits>
#include <cmath>
#include <queue>
#include <chrono>

struct Point {
    int x, y;
};

struct Edge {
    int to;
    double weight;
};

// 두 점 간의 거리 계산 함수
double calculateDistance(const Point& p1, const Point& p2) {
    int dx = p1.x - p2.x;
    int dy = p1.y - p2.y;
    return sqrt(dx * dx + dy * dy);
}

// 그래프 생성 함수
std::vector<std::vector<Edge>> createGraph(const std::vector<Point>& points, int m) {
    int N = points.size();
    std::vector<std::vector<Edge>> graph(N);

    for (int i = 0; i < N; ++i) {
        std::vector<std::pair<double, int>> distances;

        for (int j = 0; j < N; ++j) {
            if (i != j) {
                double dist = calculateDistance(points[i], points[j]);
                distances.push_back({ dist, j });
            }
        }

        std::sort(distances.begin(), distances.end());

        for (int k = 0; k < m; ++k) {
            int to = distances[k].second;
            double weight = distances[k].first;
            graph[i].push_back({ to, weight });
        }
    }

    return graph;
}

// Dijkstra 알고리즘으로 최단 경로 찾기 함수
std::pair<double, std::vector<int>> dijkstra(const std::vector<std::vector<Edge>>& graph, int start, int end) {
    int N = graph.size();
    std::vector<double> dist(N, std::numeric_limits<double>::infinity());
    std::vector<int> prev(N, -1);

    dist[start] = 0;
    std::priority_queue<std::pair<double, int>, std::vector<std::pair<double, int>>, std::greater<>> pq;
    pq.push({ 0, start });

    while (!pq.empty()) {
        double currentDist = pq.top().first;
        int current = pq.top().second;
        pq.pop();

        if (currentDist > dist[current]) {
            continue;
        }

        for (const Edge& edge : graph[current]) {
            double newDist = currentDist + edge.weight;

            if (newDist < dist[edge.to]) {
                dist[edge.to] = newDist;
                prev[edge.to] = current;
                pq.push({ newDist, edge.to });
            }
        }
    }

    // 최단 경로 구성
    std::vector<int> path;
    for (int at = end; at != -1; at = prev[at]) {
        path.push_back(at);
    }
    std::reverse(path.begin(), path.end());

    return { dist[end], path };
}

int main() {
    // 시드를 현재 시간으로 초기화하여 랜덤 값을 생성
    std::srand(static_cast<unsigned>(std::time(nullptr)));

    int N, m;
    std::cout << "N의 값과 m의 값 입력: ";
    std::cin >> N >> m;

    // N 개의 랜덤 좌표 생성
    std::vector<Point> points(N);
    for (int i = 0; i < N; ++i) {
        points[i].x = std::rand() % 101;
        points[i].y = std::rand() % 101;
    }

    // 그래프 생성
    auto startGraphCreation = std::chrono::high_resolution_clock::now();
    std::vector<std::vector<Edge>> graph = createGraph(points, m);
    auto endGraphCreation = std::chrono::high_resolution_clock::now();
    auto graphCreationDuration = std::chrono::duration_cast<std::chrono::microseconds>(endGraphCreation - startGraphCreation);

    // 최단 경로 찾기
    auto startShortestPath = std::chrono::high_resolution_clock::now();
    auto result = dijkstra(graph, 0, N - 1);
    auto endShortestPath = std::chrono::high_resolution_clock::now();
    auto shortestPathDuration = std::chrono::duration_cast<std::chrono::microseconds>(endShortestPath - startShortestPath);

    // 결과 출력
    std::cout << "그래프 생성 시간: " << graphCreationDuration.count() << " 마이크로초" << std::endl;
    std::cout << "최단 경로 찾기 시간: " << shortestPathDuration.count() << " 마이크로초" << std::endl;

    double shortestDistance = result.first;
    std::vector<int> shortestPath = result.second;

    if (std::isinf(shortestDistance)) {
        std::cout << "1 번째 점과 N 번째 점 사이에 경로가 없습니다." << std::endl;
    }
    else {
        std::cout << "1 번째 점과 N 번째 점 사이의 최단 거리: " << shortestDistance << std::endl;
        std::cout << "최단 경로: ";
        for (int node : shortestPath) {
            std::cout << node << " ";
        }
        std::cout << std::endl;
    }

    return 0;
}