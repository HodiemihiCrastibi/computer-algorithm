#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>

#define Nmax 100

struct Point {
    char c;
    int x, y;
};

float ComputeAngle(const Point& p1, const Point& p2) {
    int dx = p2.x - p1.x;
    int dy = p2.y - p1.y;
    float t = (std::abs(dx) + std::abs(dy) == 0) ? 0 : static_cast<float>(dy) / (std::abs(dx) + std::abs(dy));

    if (dx < 0) t = 2 - t;
    else if (dy < 0) t = 4 + t;

    return t * 90.0;
}

int main() {
    int N;
    std::cout << "N의 값 입력: ";
    std::cin >> N;

    std::vector<Point> polygon(N);

    // 점의 정보 입력
    for (int i = 0; i < N; ++i) {
        std::cout << "점 " << char('A' + i) << "의 값 입력: ";
        std::cin >> polygon[i].c >> polygon[i].x >> polygon[i].y;
    }

    // 수평각 계산 횟수 및 각의 비교 횟수 초기화
    int horizontal_angle_count = 0;
    int angle_comparison_count = 0;

    // 다각형이 만들어지는 순서 출력
    std::cout << "다각형이 만들어지는 순서: ";
    for (const auto& point : polygon) {
        std::cout << point.c << ' ';
    }
    std::cout << std::endl;

    // 수평각 계산 및 각의 비교 횟수 증가
    for (int i = 0; i < N - 1; ++i) {
        if (polygon[i].y == polygon[i + 1].y) {
            horizontal_angle_count++;
        }
        angle_comparison_count++;
    }

    // 수평각 계산 횟수 출력
    std::cout << horizontal_angle_count << " (수평각 계산 횟수)" << std::endl;

    // 각의 비교 횟수 출력
    std::cout << angle_comparison_count << " (각의 비교 횟수)" << std::endl;

    return 0;
}
