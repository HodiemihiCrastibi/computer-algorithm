#include <iostream>
#include <vector>

struct Point {
    char c;
    int x, y;
};

// 단순 폐쇄 경로 내부 판단 함수
bool isInsidePolygon(const Point& z, const std::vector<Point>& polygon) {
    int n = polygon.size();
    bool inside = false;

    for (int i = 0, j = n - 1; i < n; j = i++) {
        if ((polygon[i].y > z.y) != (polygon[j].y > z.y) &&
            z.x < (polygon[j].x - polygon[i].x) * (z.y - polygon[i].y) / (polygon[j].y - polygon[i].y) + polygon[i].x) {
            inside = !inside;
        }
    }

    return inside;
}

int main() {
    int N, zx, zy;
    std::cout << "N의 값과 Z의 좌표 값 입력: ";
    std::cin >> N >> zx >> zy;

    Point z = { 'Z', zx, zy };
    std::vector<Point> polygon(N);

    // 다각형의 좌표값 입력
    for (int i = 0; i < N; ++i) {
        std::cout << "점 " << char('A' + i) << "의 값 입력: ";
        std::cin >> polygon[i].c >> polygon[i].x >> polygon[i].y;
    }

    // 결과 출력
    if (isInsidePolygon(z, polygon)) {
        std::cout << "점 Z는 단순 폐쇄 경로 내부에 있습니다." << std::endl;
    }
    else {
        std::cout << "점 Z는 단순 폐쇄 경로 내부에 없습니다." << std::endl;
    }

    return 0;
}
