#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cassert>
#include <algorithm>
#include <vector>

using namespace std;


void shuffle(int* b, int size) {
    vector<pair<int, int>> a(size);

    for (int i = 0; i < size; i++) {
        a[i].first = (1 + rand()) % size;
        a[i].second = b[i];
    }
    sort(a.begin(), a.end());
    // pair<int,int>의 정렬 기준: fisrt 오름차순, second 오름차순

    for (int i = 0; i < size; i++) {
        b[i] = a[i].second;
    }
}

template<typename itemType>
struct node {
    itemType value; 
    node* next;

    node(): value(0), next(nullptr){}
};


template<typename itemType>
void radixSort(itemType *a, int n, int& compare , int& move) {
    int i,j, cnt, radix, radix_mod =10, cipher=0; 
    node<itemType>** TABLE = new node<itemType>*[10];
    for(i = 0; i < 10; i++) {
        TABLE[i] = nullptr;
    }
    node<itemType>* x = nullptr;
    node<itemType>* z= nullptr;
    node<itemType>* temp= nullptr;

    i=n;

    while(i>0) { 
        i=i/10; 
        cipher++; 
    } // cipher : 입력 데이터의 자리수 (ex. 450 -> 3)
    
    for(i=0; i<cipher; i++) {
        for(j=0; j<n; j++) {
            
            radix = (a[j]%radix_mod)/(radix_mod/10); 
            /* radix_mod = 10 이면 radix는 a[j]의 일의 자리수
            radix_mod = 100 이면 radix는 a[j]의 십의 자리수 */
            temp = new node<itemType>; 
            temp->value = a[j]; 
            temp->next = z; 
            if(TABLE[radix] == z) {  
                // z는 list의 끝을 확인하기 위한 노드 포인터 (NULL에 해당)
                TABLE[radix]=temp; 
                move += 1;
            } else {
                x=TABLE[radix]; 
                while(x->next != z) {
                    x=x->next; 
                }
                x->next=temp;
                move += 1; 
            }
            compare += 1;
        }
        cnt=0; 
        for(j=0; j<10; j++) {
            if(TABLE[j]!=z) {
                x=TABLE[j]; 
                while(x!=z) {
                    a[cnt++] = x->value; 
                    move += 1;
                    temp = x; // 메모리에서 노드를 삭제하기 위해 임시 저장
                    x=x->next; 
                    delete temp; // 배열에 이미 넣은 노드를 메모리에서 삭제
                }
            }
            TABLE[j]=z; 
        }
        radix_mod*=10; 
        
    }
    delete[] TABLE;

}



int main(){
    srand((unsigned)time(NULL));   
    int N;
    cin >> N;
    int* A = new int[N]; 
    int* B = new int[N];
    int* C = new int[N];
    for (int i = 0; i < N; i++) {
        A[i] = N - i;
        B[i] = i + 1;
        C[i] = rand() % N + 1;
    }

    shuffle(B, N);

    int Compare_Cnt_A = 0;
    int DataMove_Cnt_A = 0;
    int Compare_Cnt_B = 0;
    int DataMove_Cnt_B = 0;
    int Compare_Cnt_C = 0;
    int DataMove_Cnt_C = 0;  

    

    radixSort<int>(A, N, Compare_Cnt_A,DataMove_Cnt_A);
    cout << "SortedData_A: ";
    for(int i =0 ; i<20; i++){
        cout << A[i] << " ";
    }
    cout << endl;

    radixSort<int>(B, N, Compare_Cnt_B,DataMove_Cnt_B);
    cout << "\nSortedData_B: ";
    for(int i =0 ; i<20; i++){
        cout << B[i] << " ";
    }
    cout << endl;


    radixSort<int>(C,N,Compare_Cnt_C,DataMove_Cnt_C);
    cout << "\nSortedData_C: ";
    for(int i =0 ; i<20; i++){
        cout << C[i] << " ";
    }
    cout << endl;


    delete[] A;
    delete[] B;
    delete[] C;


    

    cout << "\nCompare_Cnt_A: " << Compare_Cnt_A << endl;
    cout << "DataMove_Cnt_A: " << DataMove_Cnt_A << endl;
    cout << "Compare_Cnt_B: " << Compare_Cnt_B << endl;
    cout << "DataMove_Cnt_B: " << DataMove_Cnt_B << endl;
    cout << "Compare_Cnt_C: " << Compare_Cnt_C << endl;
    cout << "DataMove_Cnt_C: " << DataMove_Cnt_C << endl;

    
    cin >> N;
    cout << "program exit!" << endl;
}
//g++ -g 4_1.cpp -o 4_1.exe                                              
//start 4_1.exe