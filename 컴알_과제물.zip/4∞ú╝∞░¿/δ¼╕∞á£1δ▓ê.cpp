#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cassert>
#include <algorithm>
#include <vector>

using namespace std;
#define MAX 30001

void shuffle(int* b, int size) {
    vector<pair<int, int>> a(size);

    for (int i = 0; i < size; i++) {
        a[i].first = (1 + rand()) % size;
        a[i].second = b[i];
    }
    sort(a.begin(), a.end());
    // pair<int,int>의 정렬 기준: fisrt 오름차순, second 오름차순

    for (int i = 0; i < size; i++) {
        b[i] = a[i].second;
    }
}

template<typename itemType>
void CountSort(itemType* unsorted, itemType* resultArr, itemType* countArr, int n, int k, int& compare, int& move) {
    int i, j;
    for (i = 1; i <= k; i++) {
        countArr[i] = 0;
    }
        
    for (i = 0; i < n; i++) {
        countArr[unsorted[i]] = countArr[unsorted[i]] + 1;
        compare += 1;
    }
    for (i = 2; i <= k; i++){
        countArr[i] = countArr[i] + countArr[i - 1];
        move += 1;
    } 

    for (j = n - 1; j >= 0; j--) {
        resultArr[countArr[unsorted[j]] - 1] = unsorted[j];
        countArr[unsorted[j]] = countArr[unsorted[j]] - 1;
        move += 1;
    }
}


int main(){
    srand((unsigned)time(NULL));   
    int N;
    cin >> N;
    int* A = new int[N]; 
    int* B = new int[N];
    int* C = new int[N];
    int* resultArr = new int[N];
    int* countArr = new int[MAX];
    for (int i = 0; i < N; i++) {
        A[i] = N - i;
        B[i] = i + 1;
        C[i] = rand() % N + 1;
    }

    shuffle(B, N);

    int Compare_Cnt_A = 0;
    int DataMove_Cnt_A = 0;
    int Compare_Cnt_B = 0;
    int DataMove_Cnt_B = 0;
    int Compare_Cnt_C = 0;
    int DataMove_Cnt_C = 0;  

    

    CountSort<int>(A, resultArr, countArr, N, MAX - 1,Compare_Cnt_A,DataMove_Cnt_A);
    cout << "SortedData_A: ";
    for(int i =0 ; i<20; i++){
        cout << resultArr[i] << " ";
    }
    cout << endl;

    CountSort<int>(B, resultArr, countArr, N, MAX - 1,Compare_Cnt_B,DataMove_Cnt_B);
    cout << "\nSortedData_B: ";
    for(int i =0 ; i<20; i++){
        cout << resultArr[i] << " ";
    }
    cout << endl;


    CountSort<int>(C, resultArr, countArr, N, MAX - 1,Compare_Cnt_C,DataMove_Cnt_C);
    cout << "\nSortedData_C: ";
    for(int i =0 ; i<20; i++){
        cout << resultArr[i] << " ";
    }
    cout << endl;


    delete[] A;
    delete[] B;
    delete[] C;
    delete[] resultArr;
    delete[] countArr;

    

    cout << "\nCompare_Cnt_A: " << Compare_Cnt_A << endl;
    cout << "DataMove_Cnt_A: " << DataMove_Cnt_A << endl;
    cout << "Compare_Cnt_B: " << Compare_Cnt_B << endl;
    cout << "DataMove_Cnt_B: " << DataMove_Cnt_B << endl;
    cout << "Compare_Cnt_C: " << Compare_Cnt_C << endl;
    cout << "DataMove_Cnt_C: " << DataMove_Cnt_C << endl;

    
    cin >> N;
    cout << "program exit!" << endl;
}
//g++ -g 4_1.cpp -o 4_1.exe                                              
//start 4_1.exe