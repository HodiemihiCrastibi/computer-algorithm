#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cassert>
#include <algorithm>
#include <vector>

using namespace std;

template<typename itemType>
inline void swap(itemType a[], int i, int j) { 
    itemType  t = a[i]; 
    a[i] = a[j]; 
    a[j] = t; 
} 

void shuffle(int* b, int size) {
    vector<pair<int, int>> a(size);

    for (int i = 0; i < size; i++) {
        a[i].first = (1 + rand()) % size;
        a[i].second = b[i];
    }
    sort(a.begin(), a.end());
    // pair<int,int>의 정렬 기준: fisrt 오름차순, second 오름차순

    for (int i = 0; i < size; i++) {
        b[i] = a[i].second;
    }
}

template<typename itemType>
int quick_partition(itemType a[], int l, int r, int& compare);

template<typename itemType>
void select(itemType a[], int l, int r, int k, int& compare){ 
    int j;
    if (r > l) {
        j = quick_partition(a, l, r, compare);
        
        

        if (j > l+k - 1) {
            select(a, l, j-1, k, compare);
        }
        if (j< l+k-1){ 
            select(a, j+1, r, k-j + l - 1, compare);
        }
        
    }
}

template<typename itemType>
int quick_partition(itemType a[], int l, int r, int& compare) { 
    int i, j; itemType v; 
    if (r > l) { 
        v = a[l]; 
        i = l; 
        j = r+1; 
        for (;;) { 
            while (true) {
                if (i >= r || a[++i] >= v){
                    compare += 1;
                    break;
                }
                compare += 1;
                    
            }; 
            while (true) {
                if (i <= l || a[--j] <= v){
                    compare += 1;
                    break;
                }
                compare += 1;
            }; 
            if (i >= j) 
                break; 
            swap(a, i, j); 
        } 
        swap(a, j, l); 
    return j;
    }
    return 1;
}


int main(){
    srand((unsigned)time(NULL));   
    int N;
    cin >> N; 
    int* B = new int[N];
    int* C = new int[N];
    for (int i = 0; i < N; i++) {
        B[i] = i + 1;
        C[i] = rand() % N + 1;
    }

    shuffle(B, N);

    int* cmpdmarr = new int[6];
    for (int i=0;i<6;i++){
        cmpdmarr[i] = 0;
    }

    // int Compare_Cnt_B_min = 0;
    // int Compare_Cnt_B_max = 0;
    // int Compare_Cnt_B_med = 0;
    // int Compare_Cnt_C_min = 0;
    // int Compare_Cnt_C_max = 0;
    // int Compare_Cnt_C_med = 0;


    int* B_clone1 = new int[N];
    int* B_clone2 = new int[N];


    int* C_clone1 = new int[N];
    int* C_clone2 = new int[N];

    for(int i = 0; i < N; ++i) {
        B_clone1[i] = B[i];
        B_clone2[i] = B[i];
        C_clone1[i] = C[i];
        C_clone2[i] = C[i];
    }

    select(B, 0, N-1, 0,cmpdmarr[0]);
    cout << "B min : " << B[0] << endl;
    cout << "B min # of compare : " << cmpdmarr[0] << endl;


    select(B_clone1, 0, N-1, N-1,cmpdmarr[1]);
    cout << "B max : " << B_clone1[N-1] << endl;
    cout << "B max # of compare : " << cmpdmarr[1] << endl;


    select(B_clone2, 0, N-1, N/2,cmpdmarr[2]);
    cout << "B med : " << B_clone2[N/2] << endl;
    cout << "B med # of compare : " << cmpdmarr[2] << endl;



    select(C, 0, N-1, 0,cmpdmarr[3]);
    cout << "C min : " << C[0] << endl;
    cout << "C min # of compare : " << cmpdmarr[3] << endl;
    for (int i = 0; i < N; i++) {
        C[i] = rand() % N + 1;
    }

    select(C_clone1, 0, N-1, N-1,cmpdmarr[4]);
    cout << "C max : " << C_clone1[N-1] << endl;
    cout << "C max # of compare : " << cmpdmarr[4] << endl;
    for (int i = 0; i < N; i++) {
        C[i] = rand() % N + 1;
    }

    select(C_clone2, 0, N-1, N/2,cmpdmarr[5]);
    cout << "C med : " << C_clone2[N/2] << endl;
    cout << "C med # of compare : " << cmpdmarr[5] << endl;





    delete[] B_clone1;
    delete[] B_clone2;
    delete[] C_clone1;
    delete[] C_clone2;
    delete[] B;
    delete[] C;
    delete[] cmpdmarr;

    



    
    cin >> N;
    cout << "program exit!" << endl;
}
//g++ -g 4_1.cpp -o 4_1.exe                                              
//start 4_1.exe