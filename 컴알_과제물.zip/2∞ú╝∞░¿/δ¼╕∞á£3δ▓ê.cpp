#include <iostream>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <chrono>
#include <cassert>

using namespace std;

bool compare(const int* a, const int* b) {
    return a[0] < b[0];
}
//B 배열을 생성하기 위해서 sorting할때 쓰이는 함수

template<typename itemType>
int Bubble(int sorted, itemType *a, int n,int &compare, int &move) 
{
    int temp;
    if ( *(a-1) > *a ) {
        temp = *(a-1);
        move += 1;
        *(a-1) = *a;
        move += 1;
        *a = temp;
        move += 1;
        sorted = false;
        // 둘을 스왑하기 위해 3번의 이동이 있다.
    }
    compare += 1;
    //왼쪽이 큰지 확인하는 비교가 있다.
    return sorted;
}

template<typename itemType>
void bubbleSort(itemType a[], int n,int &compare, int &move) 
{ 
    int i, Sorted; 
    Sorted = false; 
    while ( !Sorted ) {
        assert(compare >= 0 && move >= 0 && "overflow:)");
        Sorted = true;
        //Bubble 함수가 돌때 한번도 스왑이 없었으면 종료한다.
        for ( i=1; i<n; i++ )
            Sorted = Bubble( Sorted, &a[i], n , compare, move);
    }
}




int main(){
    int N;
    cin >> N;
    srand((unsigned)time(NULL));
    int *A = new int[N];
    int **tB = new int*[N];
    for(int i = 0 ; i< N; i++){
        A[i] = N - i;
        tB[i] = new int[2];
        tB[i][0] = (1+rand() % N);
        tB[i][1] = i+1;
    }
    sort(tB, tB + N, compare);

    int *B = new int[N];
    for(int i =0 ; i<N; i++){
        B[i] = tB[i][1];
        delete [] tB[i];
    }
    delete [] tB;
    // B를 선언합니다.
    int Compare_Cnt_A = 0;
    int DataMove_Cnt_A = 0;
    int Compare_Cnt_B = 0;
    int DataMove_Cnt_B = 0;
    
    // //debug
    // cout << "\nUnSortedData_A: ";
    // for(int i =0 ; i<N; i++){
    //     cout << A[i] << " ";
    // }
    
    // cout << "\nUnSortedData_B: ";
    // for(int i =0 ; i<N; i++){
    //     cout << B[i] << " ";
    // }
    // cout << "\n";
    // //debug

    auto startA = chrono::high_resolution_clock::now();
    bubbleSort(A,N,Compare_Cnt_A,DataMove_Cnt_A);
    auto endA = chrono::high_resolution_clock::now();
    auto durationA = chrono::duration_cast<chrono::microseconds>(endA-startA);
    auto startB = chrono::high_resolution_clock::now();
    bubbleSort(B,N,Compare_Cnt_B,DataMove_Cnt_B);
    auto endB = chrono::high_resolution_clock::now();
    auto durationB = chrono::duration_cast<chrono::microseconds>(endB-startB);
    // 추가적으로 시간도 쟀습니다.

    cout << "SortedData_A: ";
    for(int i =0 ; i<N; i++){
        cout << A[i] << " ";
    }
    
    cout << "\nSortedData_B: ";
    for(int i =0 ; i<N; i++){
        cout << B[i] << " ";
    }
    cout << "\nCompare_Cnt_A: " << Compare_Cnt_A << endl;
    cout << "DataMove_Cnt_A: " << DataMove_Cnt_A << endl;
    cout << "Compare_Cnt_B: " << Compare_Cnt_B << endl;
    cout << "DataMove_Cnt_B: " << DataMove_Cnt_B << endl;


    cin >> N;
}
//g++ -g 2_1.cpp -o 2_1.exe                                              
//start 2_1.exe