#include <iostream>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <chrono>
#include <cassert>

using namespace std;

bool compare(const int* a, const int* b) {
    return a[0] < b[0];
}
//B 배열을 생성하기 위해서 sorting할때 쓰이는 함수

template<typename itemType>
void insertion(itemType a[], int n, int &compare, int &move){ //insertion sort 함수입니다.
    int i, j; itemType v;
    for (i = 1; i < n ; i++){// 처음 원소는 하나이기에 이미 정렬되어있다고 생각하겠습니다.
        v = a[i]; j=i;
        move += 1; //v에 a[i]를 저장하기 위해서 이동이 발생했습니다.
        while (j > 0){
            //compare += 1; 앞으로 부터 사소한 비교(반복문 진행을 위한 j 비교)는 그냥 넘기겠습니다.
            if (a[j-1] > v){
                compare += 1;
                //삽입해야 하는 원소랑 이미 정렬되있는 부분의 원소랑 비교가 1회 일어났습니다.
                a[j] = a[j-1];
                move += 1;
                //v보다 크기에 오른쪽으로 이동해야 합니다.
                //이때 v를 이동시키지 않기에 일반적인 삽입정렬보다 이동횟수를 줄일 수 있습니다.
                j -= 1;
                
            }else{
                compare += 1;
                //if문에 걸러져서 else문으로 왔을때 카운팅해야 합니다.
                break;
            }
            assert(compare >= 0 && move >= 0 && "overflow:)");   
        }
        //compare += 1;
        a[j] = v;
        move += 1;
        //v에 저장해 두었던 원소를 정렬된 부분의 제자리에 배치합니다.
    }
}


int main(){
    int N;
    cin >> N;
    srand((unsigned)time(NULL));
    int *A = new int[N];
    int **tB = new int*[N];
    for(int i = 0 ; i< N; i++){
        A[i] = N - i;
        tB[i] = new int[2];
        tB[i][0] = (1+rand() % N);
        tB[i][1] = i+1;
    }
    sort(tB, tB + N, compare);

    int *B = new int[N];
    for(int i =0 ; i<N; i++){
        B[i] = tB[i][1];
        delete [] tB[i];
    }
    delete [] tB;
    // B를 선언합니다.

    int Compare_Cnt_A = 0;
    int DataMove_Cnt_A = 0;
    int Compare_Cnt_B = 0;
    int DataMove_Cnt_B = 0;

    // //debug
    // cout << "\nUnSortedData_A: ";
    // for(int i =0 ; i<N; i++){
    //     cout << A[i] << " ";
    // }
    
    // cout << "\nUnSortedData_B: ";
    // for(int i =0 ; i<N; i++){
    //     cout << B[i] << " ";
    // }
    // cout << "\n";
    // //debug

    auto startA = chrono::high_resolution_clock::now();
    insertion(A,N,Compare_Cnt_A,DataMove_Cnt_A);
    auto endA = chrono::high_resolution_clock::now();
    auto durationA = chrono::duration_cast<chrono::microseconds>(endA-startA);
    auto startB = chrono::high_resolution_clock::now();
    insertion(B,N,Compare_Cnt_B,DataMove_Cnt_B);
    auto endB = chrono::high_resolution_clock::now();
    auto durationB = chrono::duration_cast<chrono::microseconds>(endB-startB);
    // 추가적으로 시간도 쟀습니다.

    cout << "SortedData_A: ";
    for(int i =0 ; i<N; i++){
        cout << A[i] << " ";
    }
    
    cout << "\nSortedData_B: ";
    for(int i =0 ; i<N; i++){
        cout << B[i] << " ";
    }
    cout << "\nCompare_Cnt_A: " << Compare_Cnt_A << endl;
    cout << "DataMove_Cnt_A: " << DataMove_Cnt_A << endl;
    cout << "Compare_Cnt_B: " << Compare_Cnt_B << endl;
    cout << "DataMove_Cnt_B: " << DataMove_Cnt_B << endl;


    cout << "time_A: " << durationA.count() << endl;
    cout << "time_B: " << durationB.count() << endl;

    cin >> N;
}
//g++ -g 2_1.cpp -o 2_1.exe                                              
//start 2_1.exe