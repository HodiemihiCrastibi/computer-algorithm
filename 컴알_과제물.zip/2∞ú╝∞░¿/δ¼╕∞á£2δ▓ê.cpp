#include <iostream>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <chrono>
#include <cassert>

using namespace std;

bool compare(const int* a, const int* b) {
    return a[0] < b[0];
}
//B 배열을 생성하기 위해서 sorting할때 쓰이는 함수

template<typename itemType>
void shellSort(itemType a[], int n,int &compare, int &move) 
{ 
    int i, j, h; 
    itemType v; 

    h = 1; 
    
    compare = 0;
    move = 0;

    do {
        h = 3*h +1;
    } while (h < n); 
    do {
        h = h / 3;
        for (i = h; i < n; i++) { 
            /*
            쉘정렬이다. h개로 나눠진 배열을 삽입정렬한다.
            h개의 파트가 있을때 
            1. 첫번째 파트의 첫원소와 두번째 원소를 비교+스왑
            2. 두번째 파트의 첫원소와 두번째 원소를 비교+스왑
            ...
            h. h번째 파트의 첫원소와 두번째 원소를 비교+스왑
            h+1. 첫번째 파트의 1,2,3번째 원소끼리 삽입정렬 루프(while)
            h+2. 두번째 파트의 1,2,3번째 원소끼리 삽입정렬 루프(while)
            ...
            이런식의 코드이다.
            */ 
            
            v = a[i]; 
            move += 1;
            //삽입정렬의 루틴이랑 비슷하다.
            //v에 a[i]를 저장하기 위해서 이동이 발생했습니다.
            j = i; 
            while (a[j-h] > v)  {
                compare += 1; 
                //삽입해야 하는 원소랑 이미 정렬되있는 부분의 원소랑 비교가 1회 일어났습니다.
                a[j] = a[j-h];
                move += 1; 
                //v보다 크기에 오른쪽으로 이동해야 합니다.
                j -= h;  
                // 삽입정렬은 1씩 떨어지는데 쉘은 h씩 떨어져서 효율적이다.
                if (j <= h-1) 
                    break; 
            }
            assert(compare >= 0 && move >= 0 && "overflow:)");

            

            compare += 1; 

            a[j] = v; 
            move += 1;
            //v에 저장해 두었던 원소를 정렬된 부분의 제자리에 배치합니다.
        } 
    } while ( h > 1);
}



int main(){
    int N;
    cin >> N;
    srand((unsigned)time(NULL));
    int *A = new int[N];
    int **tB = new int*[N];
    for(int i = 0 ; i< N; i++){
        A[i] = N - i;
        tB[i] = new int[2];
        tB[i][0] = (1+rand() % N);
        tB[i][1] = i+1;
    }
    sort(tB, tB + N, compare);

    int *B = new int[N];
    for(int i =0 ; i<N; i++){
        B[i] = tB[i][1];
        delete [] tB[i];
    }
    delete [] tB;
    // B를 선언합니다.
    int Compare_Cnt_A = 0;
    int DataMove_Cnt_A = 0;
    int Compare_Cnt_B = 0;
    int DataMove_Cnt_B = 0;
    
    // //debug
    // cout << "\nUnSortedData_A: ";
    // for(int i =0 ; i<N; i++){
    //     cout << A[i] << " ";
    // }
    
    // cout << "\nUnSortedData_B: ";
    // for(int i =0 ; i<N; i++){
    //     cout << B[i] << " ";
    // }
    // cout << "\n";
    // //debug

    auto startA = chrono::high_resolution_clock::now();
    shellSort(A,N,Compare_Cnt_A,DataMove_Cnt_A);
    auto endA = chrono::high_resolution_clock::now();
    auto durationA = chrono::duration_cast<chrono::microseconds>(endA-startA);
    auto startB = chrono::high_resolution_clock::now();
    shellSort(B,N,Compare_Cnt_B,DataMove_Cnt_B);
    auto endB = chrono::high_resolution_clock::now();
    auto durationB = chrono::duration_cast<chrono::microseconds>(endB-startB);
    // 추가적으로 시간도 쟀습니다.

    cout << "SortedData_A: ";
    for(int i =0 ; i<N; i++){
        cout << A[i] << " ";
    }
    
    cout << "\nSortedData_B: ";
    for(int i =0 ; i<N; i++){
        cout << B[i] << " ";
    }
    cout << "\nCompare_Cnt_A: " << Compare_Cnt_A << endl;
    cout << "DataMove_Cnt_A: " << DataMove_Cnt_A << endl;
    cout << "Compare_Cnt_B: " << Compare_Cnt_B << endl;
    cout << "DataMove_Cnt_B: " << DataMove_Cnt_B << endl;

    cout << "time_A: " << durationA.count() << endl;
    cout << "time_B: " << durationB.count() << endl;

    cin >> N;
}
//g++ -g 2_1.cpp -o 2_1.exe                                              
//start 2_1.exe