#include <iostream>
#include <algorithm>
#include <cassert>
using namespace std;

template<typename itemType>
int Bubble(int sorted, itemType *a, int n,long &work) 
{
    int temp;
    if ( *(a-1) > *a ) {
        temp = *a;
        *a = *(a - 1);
        *(a - 1) = temp;
        sorted = false;
        work += *a * 2 + *(a - 1);
        //옮기는 방식을 좀더 효율적으로 바꿨습니다.
        //가벼운거를 두번 드는게 더 좋습니다.
        assert(work >= 0 && "work overflow:)");
    }
    return sorted;
}

template<typename itemType>
void bubbleSort(itemType a[], int n,long &work) 
{ 
    int i, Sorted; 
    Sorted = false; 
    int todo = n;
    while ( !Sorted ) {
        Sorted = true;
        for ( i=1; i<todo; i++ )
            Sorted = Bubble( Sorted, &a[i], n , work);
        todo -= 1;
    }
}

template<typename itemType>
void insertion(itemType a[], int n, long &work){
    int i, j; itemType v;
    for (i = 1; i < n ; i++){
        v = a[i]; j=i;
        work += a[j]; // 빈자리에 두기 
        assert(work >= 0 && "work overflow:)");
        while (j > 0){
            if (a[j-1] > v){
                a[j] = a[j-1];
                work += a[j-1]; 
                assert(work >= 0 && "work overflow:)");
                
                j -= 1;
            }else{
                break;
            }  
        }
        a[j] = v; 
        work += a[j]; 
        assert(work >= 0 && "work overflow:)");
    }
}

template<typename itemType>
void shellSort(itemType a[], int n,long &work) 
{ 
    int i, j, h; 
    itemType v; 

    h = 1; 

    do {
        h = 3*h +1;
    } while (h < n); 
    do {
        h = h / 3;
        for (i = h; i < n; i++) { 
            v = a[i];
            work += a[i];
            assert(work >= 0 && "work overflow:)");
            j = i; 
            while (a[j-h] > v)  {
                a[j] = a[j-h];
                work += a[j-h];
                assert(work >= 0 && "work overflow:)");
                j -= h;  
                if (j <= h-1) 
                    break; 
            }
            a[j] = v; 
            work += a[j];
            assert(work >= 0 && "work overflow:)");
        } 
    } while ( h > 1);
}
//앞선 문제들에서 정렬함수를 가져왔습니다.




int main(){
    int N;
    cin >> N;
    int *A = new int[N];
    for(int i = 0 ; i< N; i++){
        A[i] = N - i;
    }
    long bw = 0;
    long iw = 0;
    long sw = 0;
    
    int* A_clone1 = new int[N];
    int* A_clone2 = new int[N];
    int* A_clone3 = new int[N];

    for(int i = 0; i < N; ++i) {
        A_clone1[i] = A[i];
        A_clone2[i] = A[i];
        A_clone3[i] = A[i];
    }


    bubbleSort(A_clone1,N,bw);
    insertion(A_clone2,N,iw);
    shellSort(A_clone3,N,sw);


    
    cout << "\nInsertion Sort : " << iw << endl;
    cout << "\nBubble Sort : " << bw << endl;
    cout << "\nShell Sort : " << sw << endl;



    cin >> N;
}