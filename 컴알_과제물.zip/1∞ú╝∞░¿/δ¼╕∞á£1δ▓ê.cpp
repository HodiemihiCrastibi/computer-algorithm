#include <iostream>
#include <cassert>

using namespace std;

template<typename itemType>
class Stack2{
    public:
        Stack2(){
            this -> head = nullptr;
        }
        ~Stack2(){
            while (!empty()){
                this -> pop();
            }
        }
        void push(itemType v){
            node *newNode = new node{v, this -> head};
            this -> head = newNode;
        }
        itemType pop(){
            assert(!empty() && "stack2 is empty :)");
            itemType value = this -> head -> key;
            node* temp = this -> head;
            this -> head = this -> head -> next;
            delete temp;
            return value;
        };
        int empty(){
            if (this -> head == nullptr){
                return true;
            }
            return false;
        };

    private:
        struct node{
            itemType key;
            struct node *next;


        };
        struct node *head;
};

int main() {
    char c;
    Stack2<double> acc;
    double x;
    while((c = cin.get()) != '\n'){
        x = 0;
        double formal = 0.0;
        double latter = 0.0;
        while(c == ' ')
            c = cin.get();
        if (c == '+')
            x = acc.pop() + acc.pop();
        else if (c == '*')
            x = acc.pop() * acc.pop();
        else if (c == '-'){
            latter = acc.pop();
            formal = acc.pop();
            x = formal - latter;
        }else if (c == '/'){
            latter = acc.pop();
            formal = acc.pop();
            assert(latter != 0 && "cannot divide by zero :)");
            x = formal / latter;
        }
        while(c >= '0' && c <= '9'){
            x = 10 * x + ( c - '0' );
            c = cin.get();
        }
        acc.push(x);
    }
    cout << acc.pop() << endl;
}