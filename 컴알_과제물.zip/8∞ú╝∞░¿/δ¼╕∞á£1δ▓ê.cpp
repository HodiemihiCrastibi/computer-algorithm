//문제1

#include <iostream>
#include <string>
#include <vector>
#include <cmath>
#include <cassert>
using namespace std;




void initSP(string& p, vector<int>& SP) {
    int m = p.size();
    SP.resize(m);
    SP[0] = 0;
    int j = 0;
    for (int i = 1; i < m; i++) {
        if (p[i] != p[j]) {
            j = 0;
            if (p[j] == p[i]) {
                j += 1;
                SP[i] = 1;
            }
            else {
                SP[i] = 0;
            }
        }
        else {
            j += 1;
            SP[i] = SP[i - 1] + 1;
        }
    }

}

void brutesearch(string& p, string& a) {
    int m = p.size();
    int n = a.size();
    int comparisons = 0;

    for (int i = 0; i <= n - m; ++i) {
        int j;

        for (j = 0; j < m; ++j) {
            comparisons += 1;
            if (a[i + j] != p[j]) {
                break;
            }
        }
        if (j == m) {
            cout << i << " ";
        }
    }
    cout << comparisons << "(Brute-Force - 문자열의 시작의 IDX1, 문자열의 시작의 IDX2, 문자열 비교 횟수)" << endl;

}


void kmpsearch(string& p, string& a, vector<int>& SP) {
    int m = p.size();
    int n = a.size();
    int comparisons = 0;
    int q = 0;
    int b = 0;
    while (b <= n) {
        if (p[q] != a[b]) {
            if (q == 0) {

                b += 1;
            }
            else {
                q = SP[q - 1];
            }

        }
        else {
            if (q == m - 1) {
                cout << b - m + 1 << " ";
                if (q == 0) {

                    b += 1;
                }
                else {
                    q = 0;
                }

            }
            else {
                q += 1;

                b += 1;
            }

        }
        comparisons += 1;

    }

    cout << comparisons << "(KMP -문자열의 시작의 IDX1, 문자열의 시작의 IDX2, 문자열 비교 횟수)" << endl;
}

void rksearch(string& p, string& a) { // non atomic
    int m = p.size();
    int n = a.size();
    int comparisons = 0;
    int not_multiplications = 0;
    int Horner_multiplications = 0;

    int d = 26;
    int q = 33554393;
    int Hh = 0;
    int Ht = 0;
    int HD = 1;


    for (int i = 0; i <= m - 1; i++) {
        HD = (HD * d) % q;
        Hh = ((d * Hh) % q + p[i]) % q;
        Ht = ((d * Ht) % q + a[i]) % q;
        Horner_multiplications += 3;
    }

    int h = 0;
    int t = 0;
    int D = 1;

    int h_temp = 1;
    int t_temp = 1;

    for (int i = 0; i <= m - 1; i++) {
        D = (D * d) % q;
        not_multiplications += 1;

        h_temp = 1;
        t_temp = 1;

        for (int j = 0; j < i; j++) {
            h_temp = (h_temp * d) % q;
            t_temp = (t_temp * d) % q;
            not_multiplications += 2;
        }

        h += (h_temp * p[m - 1 - i]) % q;
        t += (t_temp * a[m - 1 - i]) % q;
        not_multiplications += 2;
    }

    assert(Hh == h && Ht == t && HD == D && "Horner should be same operation with not Horner");



    for (int s = 0; s < n - m + 1; s++) {
        comparisons += 1;
        if (h == t) {
            int i;
            for (i = 0; i < m; i++) {
                comparisons += 1;
                if (a[s + i] != p[i])
                    break;
            }

            if (i == m) {
                cout << s << " ";
            }
        }


        if (s < n - m) {
            t = (((d * t) % q) - ((D * a[s]) % q) + a[s + m]) % q;
            if (t < 0) {
                t += q;
            }
            not_multiplications += 2;
            Horner_multiplications += 2;
        }
    }

    cout << comparisons << "(Rabin-Karp -문자열의 시작의 IDX1, 문자열의 시작의 IDX2, 문자열 비교 횟수)" << endl;
    cout << Horner_multiplications << " vs " << not_multiplications << "(Rabin-Karp * 수행 횟수, Horner vs not) " << endl;
}

int main() {
    string text = "A STRING SEARCHING EXAMPLE CONSISTING OF A GIVEN STING";
    string pattern = "STING";

    vector<int> SP;
    initSP(pattern, SP);

    brutesearch(pattern, text);
    kmpsearch(pattern, text, SP);
    rksearch(pattern, text);

    return 0;
}
