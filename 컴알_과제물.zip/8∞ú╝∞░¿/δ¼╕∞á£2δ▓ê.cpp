//문제2

#include <iostream>
#include <string>
#include <vector>
#include <cmath>
#include <cassert>
using namespace std;

int bruteforcesearch(char** text, char** pattern) {
    int comparisons = 0;

    for (int i = 0; i <= 90; i+=1) {
        for (int j = 0; j <= 90; j+=1) {
            bool flag = true;
            for (int k = 0; k < 10; k+=1) {
                if (!flag) break;
                for (int l = 0; l < 10; l+=1) {
                    comparisons+=1;
                    if (text[i + k][j + l] != pattern[k][l]) {
                        flag = false;
                        break;
                    }
                }
            }
            if (flag) {
                cout << i << "행" << j << "열" << endl;
            }
        }
    }
    return comparisons;
}



int rksearch(char** text, char** pattern, int q) { // non atomic



    vector<int> flatten_temp;
    int m = 10;
    int n = 100; // number of line!!! not all contents!!

    int comparisons = 0;


    int d = 26;
    
    int h = 0;
    int t = 0;

    vector<int> D;
    D.resize(100);
    D[0] = 1;
    for (int i = 1; i < 100; i++) {
        D[i] = (D[i - 1] * d) % q;
    }


    for (int i = 0; i <= m - 1; i++) {
        for (int j = 0;j <= m - 1;j++) {
            h = ((d * h) % q + pattern[i][j]) % q;
            t = ((d * t) % q + text[i][j]) % q;
        }
    }



    

    



    for (int si = 0; si < n - m + 1; si++) {
        for (int sj = 0;sj < n - m + 1;sj++) {
            comparisons += 1;
            if (h == t) {
                comparisons += 1;
                bool flag = true;
                for (int i = 0; i < m; i++) {
                    if (!flag) break;
                    for (int j = 0; j < m; j++) {
                        if (text[si + i][sj + j] != pattern[i][j])
                            flag = false;
                            break;
                    }
                }
                if (flag) {
                    cout << si << "행" << sj << "열" << endl;
                }
                
            }

            if (sj == n - m) {
                if (si == n - m) {
                    break;
                }
                else {
                    t = 0;
                    for (int i = 0; i <= m - 1; i++) {
                        for (int j = 0;j <= m - 1;j++) {
                            t = ((d * t) % q + text[si + 1 + i][j]) % q;
                        }
                    }
                }
                
            }
            else {
                t = 0;
                for (int i = 0; i <= m - 1; i++) {
                    for (int j = 0;j <= m - 1;j++) {
                        t = ((d * t) % q + text[si + i][sj + 1 + j]) % q;
                    }
                }


            }
        }
        
        


        
    }
    return comparisons;


}

int main() {
    char** text = new char*[100];
    for (int i = 0; i < 100; i++) {
        text[i] = new char[100];
        for (int j = 0; j < 100; j++) {
            text[i][j] = 'A';
        }
    }

    char** pattern = new char* [10];
    for (int i = 0; i < 10; i++) {
        pattern[i] = new char[10];
        for (int j = 0; j < 10; j++) {
            pattern[i][j] = 'A';
        }
    }
    pattern[9][9] = 'B';

    

    
    cout << bruteforcesearch(text, pattern) << " (Brute Force 문자열 비교 횟수)" << endl;

    cout << rksearch(text, pattern, 10) << " (Rabin-Karp 문자열 비교 횟수 q : 10)" << endl;
    cout << rksearch(text, pattern, 100) << " (Rabin-Karp 문자열 비교 횟수 q : 100)" << endl;
    cout << rksearch(text, pattern, 1000) << " (Rabin-Karp 문자열 비교 횟수 q : 1000)" << endl;
    cout << rksearch(text, pattern, 10000) << " (Rabin-Karp 문자열 비교 횟수 q : 10000)" << endl;
    


    return 0;
}
