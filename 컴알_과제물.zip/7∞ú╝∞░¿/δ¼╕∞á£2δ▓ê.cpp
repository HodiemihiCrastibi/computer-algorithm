//문제2
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <algorithm>
using namespace std;

#define infoNIL 0
#define itemMIN -1
#define black 0
#define red 1

typedef int itemType;
typedef double infoType;

void shuffle(int* b, int size) {
    vector<pair<int, int>> a(size);

    for (int i = 0; i < size; i++) {
        a[i].first = (1 + rand()) % size;
        a[i].second = b[i];
    }
    sort(a.begin(), a.end());
    // pair<int,int>의 정렬 기준: fisrt 오름차순, second 오름차순

    for (int i = 0; i < size; i++) {
        b[i] = a[i].second;
    }
}

class RBTree {
private:
    struct node {
        itemType key, tag;
        infoType info;
        struct node* l, * r;
        node(itemType k, infoType i, itemType t, struct node* ll, struct node* rr) {
            key = k; info = i; tag = t; l = ll; r = rr;
        }
    };
    struct node* head, * tail, * x, * p, * g, * gg, * z;
    int comparisons;

public:

    RBTree(int max) {
        z = new node(0, infoNIL, black, 0, 0);
        z->l = z; z->r = z;
        head = new node(itemMIN, infoNIL, black, z, z);
    }

    void insert(itemType k, infoType info) {
        comparisons = 0;
        x = head; p = head; g = head;
        while (x != z) {
            gg = g; g = p; p = x;
            //x = (k < x->key) ? x->l : x->r;
            if (k < x->key) {
                comparisons += 1;
                x = x->l;
            }
            else {
                comparisons += 1;
                x = x->r;
            }
            if (x->l->tag && x->r->tag) split(k);
        }
        x = new node(k, info, red, z, z);
        if (k < p->key) p->l = x; else p->r = x;
        split(k); head->r->tag = black;
    }

    struct node* rotate(itemType k, struct node* y) {
        struct node* high, * low;
        if (k < y->key) {
            comparisons += 1;
            high = y->l;
        }
        else {
            comparisons += 1;
            high = y->r;
        }
        if (k < high->key) {
            comparisons += 1;
            low = high->l;
            high->l = low->r;
            low->r = high;
        }
        else {
            comparisons += 1;
            low = high->r;
            high->r = low->l;
            low->l = high;
        }
        if (k < y->key) {
            comparisons += 1;
            y->l = low;
        }
        else {
            comparisons += 1;
            y->r = low;
        }
        return low;
    }
    void split(itemType k) {
        x->tag = red; x->l->tag = black; x->r->tag = black;
        if (p->tag) {
            g->tag = red;
            if (k < g->key != k < p->key) {
                comparisons += 1;
                p = rotate(k, g);
            }
            else {
                comparisons += 1;
            }
            x = rotate(k, gg);
            x->tag = black;
        }
    }
    infoType search(itemType k) {
        comparisons = 0;
        x = head;

        while (x != z) {
            if (x->key == k) {
                comparisons += 1;
                return x->info;
            }
            else if (x->key > k) {
                comparisons += 1;
                x = x->l;
            }
            else {
                comparisons += 1;
                x = x->r;
            }
        }

        return x->info;
        // Red-Black Tree의 값을 탐색 기능 구현
    }

    int getComparisons() {
        return comparisons;
    }

};

class HT {
private:
    struct node {
        itemType key;
        infoType info;
        node* next;

        node(itemType k, infoType i, node* nextnode) {// node 생성시 초기값
            key = k; 
            info = i; 
            next = nextnode;
        };

    };
    node *z;   // z : List 의 끝을 대표하는 node pointer – NULL 에 해당

    int M;
    vector<node*> listtable;
    int comparisons;

public:
    HT(int size){
        z = new node(0, infoNIL, 0);
        M = size;
        listtable.resize(M, z);
        comparisons = 0;
    }

    int hash(itemType key) {
        return key % M;
    }

    void insert(itemType key, infoType info) {
        comparisons = 0;
        int h = hash(key);
        node* newNode = new node(key, info,z);
        if (listtable[h] == z) {
            listtable[h] = newNode;
        }
        else {
            node* parent = listtable[h];
            while (parent->next != z) {
                comparisons += 1; //키간 비교는 아니지만 해쉬 공간이 작거나 해쉬 알고리즘이 별로일때 거의 그냥 링크드 리스트처럼 된다.
                parent = parent->next;
            }
            comparisons += 1;
            parent->next = newNode;
        }
    }

    infoType search(itemType key) {
        comparisons = 0;
        int h = hash(key);
        node* tg = listtable[h];
        while (tg != z) {
            if (tg->key == key) {
                comparisons += 1;
                return tg->info;
            }
            else {
                comparisons += 1;
            }
            tg = tg->next;
        }
        return infoNIL; 
    }

    int getComparisons() {
        return comparisons;
    }
};

int main() {
    srand((unsigned)time(NULL));
    int N;
    cin >> N;
    int target;
    RBTree t3(N);
    int* numbers = new int[N];
    vector<pair<itemType, infoType>> traversalresult;

    for (int i = 0; i < N; i++) {

        numbers[i] = i;

    }
    shuffle(numbers, N);


    int cnt = 0;

    int comparisons1_1 = 0;
    for (int i = 0; i < N; i++) {
        t3.insert(numbers[i], cnt++);
        comparisons1_1 += t3.getComparisons();
    }

    int comparisons2_1 = 0;
    for (int i = 0; i < 100; i++) {
        int rnd = rand() % (2 * N); // 스케일 적당히 조절한 랜덤
        t3.search(rnd);
        comparisons2_1 += t3.getComparisons();
    }

   
    HT ht1(11);
    int comparisons1_2 = 0;
    for (int i = 0; i < N; i++) {
        ht1.insert(numbers[i], cnt++);
        comparisons1_2 += ht1.getComparisons();
    }
    int comparisons2_2 = 0;
    for (int i = 0; i < 100; i++) {
        int rnd = rand() % (2 * N);
        ht1.search(rnd);
        comparisons2_2 += ht1.getComparisons();
    }

    HT ht2(101);
    int comparisons1_3 = 0;
    for (int i = 0; i < N; i++) {
        ht2.insert(numbers[i], cnt++);
        comparisons1_3 += ht2.getComparisons();
    }
    int comparisons2_3 = 0;
    for (int i = 0; i < 100; i++) {
        int rnd = rand() % (2 * N);
        ht2.search(rnd);
        comparisons2_3 += ht2.getComparisons();
    }

    HT ht3(1009);
    int comparisons1_4 = 0;
    for (int i = 0; i < N; i++) {
        ht3.insert(numbers[i], cnt++);
        comparisons1_4 += ht3.getComparisons();
    }
    int comparisons2_4 = 0;
    for (int i = 0; i < 100; i++) {
        int rnd = rand() % (2 * N);
        ht3.search(rnd);
        comparisons2_4 += ht3.getComparisons();
    }


    

   

    


    cout << (double)comparisons1_1 / (double)N << "( T3의 구축 시 평균 비교 회수 )" << endl;
    cout << (double)comparisons1_2 / (double)N << "( Hash Table 크기가 11인 경우의 구축 시 평균 비교 횟수 )" << endl;
    cout << (double)comparisons1_3 / (double)N << "( Hash Table 크기가 101인 경우의 구축 시 평균 비교 횟수 )" << endl;
    cout << (double)comparisons1_4 / (double)N << "( Hash Table 크기가 1009인 경우의 구축 시 평균 비교 횟수 )\n" << endl;
    

    cout << (double)comparisons2_1 / (double)100 << "( T3의 평균 비교 회수 )" << endl;
    cout << (double)comparisons2_2 / (double)100 << "( Hash Table 크기가 11인 경우 평균 비교 회수 )" << endl;
    cout << (double)comparisons2_3 / (double)100 << "( Hash Table 크기가 101인 경우 평균 비교 회수 )" << endl;
    cout << (double)comparisons2_4 / (double)100 << "( Hash Table 크기가 1009인 경우 평균 비교 회수 )" << endl;




    return 0;
}
