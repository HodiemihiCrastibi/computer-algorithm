//문제1
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <algorithm>
using namespace std;

#define infoNIL 0
#define itemMIN -1
#define black 0
#define red 1

typedef int itemType;
typedef double infoType;

void shuffle(int* b, int size) {
    vector<pair<int, int>> a(size);

    for (int i = 0; i < size; i++) {
        a[i].first = (1 + rand()) % size;
        a[i].second = b[i];
    }
    sort(a.begin(), a.end());
    // pair<int,int>의 정렬 기준: fisrt 오름차순, second 오름차순

    for (int i = 0; i < size; i++) {
        b[i] = a[i].second;
    }
}

class BST {
private:
    struct node {
        itemType key;
        infoType info;
        node* l, * r;

        node(itemType k, infoType i, node* ll, node* rr) {// node 생성시 초기값
            key = k; info = i; l = ll; r = rr;
        };

    };
    node* head, * z;   // z : List 의 끝을 대표하는 node pointer – NULL 에 해당
    int comparisons;



public:
    BST(int max) {
        // key info left right
        z = new node(0, infoNIL, 0, 0);
        head = new node(itemMIN, infoNIL, z, z);
        comparisons = 0;


    }

    ~BST() {
        deleteTree(head, z);
        delete z;

    }

    infoType BSTsearch(itemType v) {
        comparisons = 0;
        node* parent = head;


        while (1) {
            if (parent->key < v) {

                parent = parent->r;
                comparisons += 1;
                if (parent == z) {
                    return infoNIL;
                }
            }
            else if (parent->key > v) {
                parent = parent->l;
                comparisons += 1;
                if (parent == z) {
                    return infoNIL;
                }
            }
            else {
                comparisons += 1;
                return parent->info;
            }
        }
    }
    void BSTinsert(itemType v, infoType info) {
        comparisons = 0;
        node* parent = head;
        node* pastparent;

        while (1) {
            pastparent = parent;
            if (parent->key < v) {
                comparisons += 1;
                parent = parent->r;
                if (parent == z) {
                    node* newnode = new node(v, info, z, z);
                    pastparent->r = newnode;
                    break;
                }
            }
            else {
                comparisons += 1;
                parent = parent->l;
                if (parent == z) {
                    node* newnode = new node(v, info, z, z);
                    pastparent->l = newnode;
                    break;
                }
            }
        }
    }

    void deleteTree(node* t, node* z) {
        if (t != z) {
            deleteTree(t->l, z);
            deleteTree(t->r, z);
            delete t;

        }
    }

    int getComparisons() {
        return comparisons;
    }

    void visit(node* t, vector<pair<itemType, infoType>>& tr) {
        tr.push_back(make_pair(t->key, t->info));
    }

    void traverse(node* t, node* z, vector<pair<itemType, infoType>>& tr) {
        if (t != z) {
            traverse(t->l, z, tr);
            visit(t, tr);
            traverse(t->r, z, tr);
        }
    }

    void inordertraverse(vector<pair<itemType, infoType>>& tr) {
        traverse(head, z, tr);
    }

};




class RBTree {
private:
    struct node {
        itemType key, tag;
        infoType info;
        struct node* l, * r;
        node(itemType k, infoType i, itemType t, struct node* ll, struct node* rr) {
            key = k; info = i; tag = t; l = ll; r = rr;
        }
    };
    struct node* head, * tail, * x, * p, * g, * gg, * z;
    int comparisons;

public:

    RBTree(int max) {
        z = new node(0, infoNIL, black, 0, 0);
        z->l = z; z->r = z;
        head = new node(itemMIN, infoNIL, black, z, z);
    }

    void insert(itemType k, infoType info) {
        comparisons = 0;
        x = head; p = head; g = head;
        while (x != z) {
            gg = g; g = p; p = x;
            //x = (k < x->key) ? x->l : x->r;
            if (k < x->key) {
                comparisons += 1;
                x=x->l;
            }
            else {
                comparisons += 1;
                x=x->r;
            }
            if (x->l->tag && x->r->tag) split(k);
        }
        x = new node(k, info, red, z, z);
        if (k < p->key) p->l = x; else p->r = x;
        split(k); head->r->tag = black;
    }

    struct node* rotate(itemType k, struct node* y) {
        struct node* high, * low;
        if (k < y->key) {
            comparisons += 1;
            high = y->l;
        }
        else {
            comparisons += 1;
            high = y->r;
        }
        if (k < high->key) { 
            comparisons += 1;
            low = high->l; 
            high->l = low->r; 
            low->r = high; 
        }
        else { 
            comparisons += 1;
            low = high->r; 
            high->r = low->l; 
            low->l = high; 
        }
        if (k < y->key) {
            comparisons += 1;
            y->l = low;
        }
        else { 
            comparisons += 1;
            y->r = low;
        }
        return low;
    }
    void split(itemType k) {
        x->tag = red; x->l->tag = black; x->r->tag = black;
        if (p->tag) {
            g->tag = red;
            if (k < g->key != k < p->key) {
                comparisons += 1;
                p = rotate(k, g);
            }
            else {
                comparisons += 1;
            }
            x = rotate(k, gg);
            x->tag = black;
        }
    }
    infoType search(itemType k) {
        comparisons = 0;
        x = head;

        while (x!= z) {
            if (x->key == k) {
                comparisons += 1;
                return x->info;
            }
            else if (x->key > k) {
                comparisons += 1;
                x = x->l;
            }
            else {
                comparisons += 1;
                x = x->r;
            }
        }

        return x->info;
        // Red-Black Tree의 값을 탐색 기능 구현
    }

    int getComparisons() {
        return comparisons;
    }

};





int main() {
    srand((unsigned)time(NULL));
    int N;
    cin >> N;
    int target;
    BST t1(N);
    int* numbers = new int[N];
    vector<pair<itemType, infoType>> traversalresult;

    for (int i = 0; i < N; i++) {

        numbers[i] = i;

    }
    shuffle(numbers, N);


    int cnt = 0;

    int comparisonst1_1 = 0;
    for (int i = 0; i < N; i++) {
        t1.BSTinsert(numbers[i], cnt++);
        comparisonst1_1 += t1.getComparisons();
    }

    int comparisonst2_1 = 0;
    for (int i = 0; i < 100; i++) {
        int rnd = rand() % (2 * N); // 스케일 적당히 조절한 랜덤
        t1.BSTsearch(rnd);
        comparisonst2_1 += t1.getComparisons();
    }

    

    t1.inordertraverse(traversalresult);



    BST t2(N);

    int comparisonst1_2 = 0;
    for (auto& p : traversalresult) {
        t2.BSTinsert(p.first, (double)p.second);
        comparisonst1_2 += t2.getComparisons();
    }

    int comparisonst2_2 = 0;
    for (int i = 0; i < 100; i++) {
        int rnd = rand() % (2 * N);
        t2.BSTsearch(rnd);
        comparisonst2_2 += t2.getComparisons();
    }

    RBTree t3(N);
    int comparisonst1_3 = 0;
    for (auto& p : traversalresult) {
        t3.insert(p.first, (double)p.second);
        comparisonst1_3 += t3.getComparisons();
    }

    int comparisonst2_3 = 0;
    for (int i = 0; i < 100; i++) {
        int rnd = rand() % (2 * N);
        t3.search(rnd);
        comparisonst2_3 += t3.getComparisons();
    }


    cout << (double)comparisonst1_1 / (double)N << "( T1의 구축 시 평균 비교 회수 )" << endl;
    cout << (double)comparisonst1_2 / (double)N << "( T2의 구축 시 평균 비교 회수 )" << endl;
    cout << (double)comparisonst1_3 / (double)N << "( T3의 구축 시 평균 비교 회수 )" << endl;
    cout << (double)comparisonst2_1 / (double)100 << "( T1의 평균 탐색 비교 회수 )" << endl;
    cout << (double)comparisonst2_2 / (double)100 << "( T2의 평균 탐색 비교 회수 )" << endl;
    cout << (double)comparisonst2_3 / (double)100 << "( T3의 평균 탐색 비교 회수 )" << endl;


    return 0;
}
