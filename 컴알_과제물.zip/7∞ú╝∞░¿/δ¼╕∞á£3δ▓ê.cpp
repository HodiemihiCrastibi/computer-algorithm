//문제3
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <algorithm>
#include <string>
using namespace std;

#define infoNIL 0
#define itemMIN -1

typedef string itemType;
typedef double infoType;


long long getNextPrime(long long current) {
    current += 1;
    while (true) {
        bool isPrime = true;
        for (long long i = 2; i <= sqrt(current); i++) {
            if (current% i == 0) {
                isPrime = false;
                break;
            }
        }
        if (isPrime) 
            return current;
        current += 1;
    }
}




string RandomString() {
    string result = "";
    int limit = rand() % 100;
    char randchar;
    for (int i = 0; i < limit; i++) {
        randchar = 'a' + rand() % 26;
        result += randchar;
    }
    return result;
}

int mod_pow(long long base, int exp, int mod) {
    int result = 1;
    base %= mod;

    while (exp > 0) {

        if (exp % 2 == 1) {
            result = (result * base) % mod;
        }

        base = (base * base) % mod;
        exp = exp / 2;
    }

    return result;
}



class HT {
private:
    struct node {
        itemType key;
        infoType info;
        node* next;

        node(itemType k, infoType i, node* nextnode) {// node 생성시 초기값
            key = k; 
            info = i; 
            next = nextnode;
        };

    };
    node *z;   // z : List 의 끝을 대표하는 node pointer – NULL 에 해당

    int M;
    vector<node*> listtable;
    int comparisons;
    int version;

public:
    HT(int size, int hashversion){
        z = new node("0", infoNIL, 0);
        M = size;
        listtable.resize(M, z);
        comparisons = 0;
        version = hashversion;
    }

    int modm(int a, int b) {
        
        int result = a % b;
        if (result < 0) {
            result += b;
        }
        return result;
    }

    int hash(itemType key) {
        if (version == 0) {
            return modm(hashCode1(key),  M);
        }
        else if (version == 1) {
            
            return modm(hashCode3(key) , M);
        }
        else {
            return modm(javaHashCode(key) , M);
        }
    }

    int hashCode1(string input) {
        return input.length();
    }

    int hashCode3(string input) {
        int output = 1;
        long long nextPrime = 2;
        for (char c : input) {
            nextPrime = getNextPrime(nextPrime);
            output *= mod_pow(nextPrime, (int)c, M);
        }
        return mod_pow(nextPrime, input.length(), M);
    }


    int javaHashCode(string str) {
        int hashCode = 0;
        int prime = 31;
        for (char c : str) {
            hashCode = (hashCode * prime) % M + (int)c % M;
        }
        return hashCode;
    }

    void insert(itemType key, infoType info) {
        comparisons = 0;
        int h = hash(key);
        node* newNode = new node(key, info,z);
        if (listtable[h] == z) {
            listtable[h] = newNode;
        }
        else {
            node* parent = listtable[h];
            while (parent->next != z) {
                comparisons += 1; //키간 비교는 아니지만 해쉬 공간이 작거나 해쉬 알고리즘이 별로일때 거의 그냥 링크드 리스트처럼 된다.
                parent = parent->next;
            }
            comparisons += 1;
            parent->next = newNode;
        }
    }

    infoType search(itemType key) {
        comparisons = 0;
        int h = hash(key);
        node* tg = listtable[h];
        while (tg != z) {
            if (tg->key == key) {
                comparisons += 1;
                return tg->info;
            }
            else {
                comparisons += 1;
            }
            tg = tg->next;
        }
        return infoNIL; 
    }

    int getComparisons() {
        return comparisons;
    }
};

int main() {
    srand((unsigned)time(NULL));
    int N;
    cin >> N;
    int target;
    string* strs = new string[N];

    for (int i = 0; i < N;) {

        string candi = RandomString();

        bool isduplicate = false;
        for (int j = 0; j < i; j++) {
            if (strs[j] == candi) {
                isduplicate = true;
                break;
            }
        }

        
        if (!isduplicate) {
            strs[i] = candi;
            i++;  
        }

    }


    int cnt = 0;

   
    HT ht1(N/2,0);

    for (int i = 0; i < N; i++) {
        ht1.insert(strs[i], cnt++);

    }
    string rnd;
    int comparisons2_2 = 0;
    for (int i = 0; i < 100; i++) {
        
        int rndidx = rand() % N;
        rnd = strs[rndidx];
        comparisons2_2 += ht1.getComparisons();
    }

    HT ht2(N / 2,1);

    for (int i = 0; i < N; i++) {
        ht2.insert(strs[i], cnt++);

    }
    int comparisons2_3 = 0;
    for (int i = 0; i < 100; i++) {
        int rndidx = rand() % N;
        rnd = strs[rndidx];
        ht2.search(rnd);
        comparisons2_3 += ht2.getComparisons();
    }

    HT ht3(N / 2,2);

    for (int i = 0; i < N; i++) {
        ht3.insert(strs[i], cnt++);

    }
    int comparisons2_4 = 0;
    for (int i = 0; i < 100; i++) {
        int rndidx = rand() % N;
        rnd = strs[rndidx];
        ht3.search(rnd);
        comparisons2_4 += ht3.getComparisons();
    }



    

   
    cout << (double)comparisons2_2 / (double)100 << "( implementation1 )" << endl;
    cout << (double)comparisons2_3 / (double)100 << "( implementation3 )" << endl;
    cout << (double)comparisons2_4 / (double)100 << "( Java hashCode )" << endl;




    return 0;
}
